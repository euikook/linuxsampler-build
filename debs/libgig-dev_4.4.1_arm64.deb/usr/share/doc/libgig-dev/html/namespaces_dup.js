var namespaces_dup =
[
    [ "DLS", "namespaceDLS.html", "namespaceDLS" ],
    [ "gig", "namespacegig.html", "namespacegig" ],
    [ "Korg", "namespaceKorg.html", "namespaceKorg" ],
    [ "RIFF", "namespaceRIFF.html", "namespaceRIFF" ],
    [ "Serialization", "namespaceSerialization.html", "namespaceSerialization" ],
    [ "sf2", "namespacesf2.html", "namespacesf2" ]
];
var classDiskImage =
[
    [ "DiskImage", "classDiskImage.html#ae3a24ed984954d30ee8d606c31b4de9f", null ],
    [ "DiskImage", "classDiskImage.html#ae9aeca1ba4c02fe0ce990710dd68a884", null ],
    [ "Read", "classDiskImage.html#aabb7072f7ed762b65438c180d4409eac", null ],
    [ "ReadInt16", "classDiskImage.html#a3ba0ace9d66c45da60850eebdca219b2", null ],
    [ "ReadInt32", "classDiskImage.html#a6a8317771b28d3e1f3d5a61560fa54d0", null ],
    [ "ReadInt8", "classDiskImage.html#a797ebdef6d63d1a392f2a70eeb56818b", null ],
    [ "WriteImage", "classDiskImage.html#aa6de801c063d8ada5376ad9b78b5557f", null ]
];
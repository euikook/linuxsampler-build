var classSerialization_1_1Member =
[
    [ "Member", "classSerialization_1_1Member.html#a108e10d5f827aeaeef8a61f2de4124bd", null ],
    [ "isValid", "classSerialization_1_1Member.html#aaaa00dbcc1f49fff3adb783dbdd88ff6", null ],
    [ "name", "classSerialization_1_1Member.html#a7f0e8f6bde8a956dccc821a9553f4873", null ],
    [ "offset", "classSerialization_1_1Member.html#a6eec16ea98dc2a25007645fa054f59a6", null ],
    [ "operator bool", "classSerialization_1_1Member.html#a13759e100e735e1e0ff86758684b408f", null ],
    [ "operator!=", "classSerialization_1_1Member.html#a1274908cb2e32e0f448e43f360c010c9", null ],
    [ "operator<", "classSerialization_1_1Member.html#a4adc652a42d02a80256998097ab9c420", null ],
    [ "operator==", "classSerialization_1_1Member.html#a90f6cc341207f74a20a1f21a97ca4da6", null ],
    [ "operator>", "classSerialization_1_1Member.html#a6c8df7a1ccf3fb387e92cdbb028c440b", null ],
    [ "type", "classSerialization_1_1Member.html#a90ff1ae9c237990a879cd01ed6a3662e", null ],
    [ "uid", "classSerialization_1_1Member.html#ac47bf0bb5f6fa8ed050f33b1134fe9a7", null ]
];
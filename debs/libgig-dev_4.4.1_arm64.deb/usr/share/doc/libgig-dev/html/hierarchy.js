var hierarchy =
[
    [ "AkaiDisk", "classAkaiDisk.html", null ],
    [ "AkaiPartition", "classAkaiPartition.html", null ],
    [ "AkaiProgram", "classAkaiProgram.html", null ],
    [ "AkaiVolume", "classAkaiVolume.html", null ],
    [ "Serialization::Archive", "classSerialization_1_1Archive.html", null ],
    [ "gig::buffer_t", "structgig_1_1buffer__t.html", null ],
    [ "sf2::Sample::buffer_t", "structsf2_1_1Sample_1_1buffer__t.html", null ],
    [ "RIFF::Chunk", "classRIFF_1_1Chunk.html", [
      [ "RIFF::List", "classRIFF_1_1List.html", [
        [ "RIFF::File", "classRIFF_1_1File.html", null ]
      ] ]
    ] ],
    [ "DLS::Connection", "classDLS_1_1Connection.html", null ],
    [ "gig::crossfade_t", "structgig_1_1crossfade__t.html", null ],
    [ "Serialization::DataType", "classSerialization_1_1DataType.html", null ],
    [ "gig::dimension_def_t", "structgig_1_1dimension__def__t.html", null ],
    [ "DiskImage", "classDiskImage.html", null ],
    [ "DLS::dlsid_t", "structDLS_1_1dlsid__t.html", null ],
    [ "gig::eg_opt_t", "structgig_1_1eg__opt__t.html", null ],
    [ "RIFF::Exception", "classRIFF_1_1Exception.html", [
      [ "DLS::Exception", "classDLS_1_1Exception.html", [
        [ "gig::Exception", "classgig_1_1Exception.html", null ]
      ] ],
      [ "Korg::Exception", "classKorg_1_1Exception.html", null ]
    ] ],
    [ "Serialization::Exception", "classSerialization_1_1Exception.html", null ],
    [ "Korg::KMPInstrument", "classKorg_1_1KMPInstrument.html", null ],
    [ "Korg::KMPRegion", "classKorg_1_1KMPRegion.html", null ],
    [ "Korg::KSFSample", "classKorg_1_1KSFSample.html", null ],
    [ "gig::leverage_ctrl_t", "structgig_1_1leverage__ctrl__t.html", null ],
    [ "Serialization::Member", "classSerialization_1_1Member.html", null ],
    [ "gig::MidiRule", "classgig_1_1MidiRule.html", [
      [ "gig::MidiRuleAlternator", "classgig_1_1MidiRuleAlternator.html", null ],
      [ "gig::MidiRuleCtrlTrigger", "classgig_1_1MidiRuleCtrlTrigger.html", null ],
      [ "gig::MidiRuleLegato", "classgig_1_1MidiRuleLegato.html", null ],
      [ "gig::MidiRuleUnknown", "classgig_1_1MidiRuleUnknown.html", null ]
    ] ],
    [ "Serialization::Object", "classSerialization_1_1Object.html", null ],
    [ "gig::playback_state_t", "structgig_1_1playback__state__t.html", null ],
    [ "sf2::Sample::PlaybackState", "classsf2_1_1Sample_1_1PlaybackState.html", null ],
    [ "RIFF::progress_t", "structRIFF_1_1progress__t.html", null ],
    [ "DLS::range_t", "structDLS_1_1range__t.html", null ],
    [ "gig::range_t", "structgig_1_1range__t.html", null ],
    [ "sf2::Region", "classsf2_1_1Region.html", null ],
    [ "DLS::sample_loop_t", "structDLS_1_1sample__loop__t.html", null ],
    [ "DLS::Storage", "classDLS_1_1Storage.html", [
      [ "DLS::Articulation", "classDLS_1_1Articulation.html", null ],
      [ "DLS::Articulator", "classDLS_1_1Articulator.html", [
        [ "DLS::Instrument", "classDLS_1_1Instrument.html", [
          [ "gig::Instrument", "classgig_1_1Instrument.html", null ]
        ] ],
        [ "DLS::Region", "classDLS_1_1Region.html", [
          [ "gig::Region", "classgig_1_1Region.html", null ]
        ] ]
      ] ],
      [ "DLS::Info", "classDLS_1_1Info.html", null ],
      [ "DLS::Resource", "classDLS_1_1Resource.html", [
        [ "DLS::File", "classDLS_1_1File.html", [
          [ "gig::File", "classgig_1_1File.html", null ]
        ] ],
        [ "DLS::Instrument", "classDLS_1_1Instrument.html", null ],
        [ "DLS::Region", "classDLS_1_1Region.html", null ],
        [ "DLS::Sample", "classDLS_1_1Sample.html", [
          [ "gig::Sample", "classgig_1_1Sample.html", null ]
        ] ]
      ] ],
      [ "DLS::Sampler", "classDLS_1_1Sampler.html", [
        [ "DLS::Region", "classDLS_1_1Region.html", null ],
        [ "gig::DimensionRegion", "classgig_1_1DimensionRegion.html", null ]
      ] ],
      [ "gig::Group", "classgig_1_1Group.html", null ],
      [ "gig::Script", "classgig_1_1Script.html", null ],
      [ "gig::ScriptGroup", "classgig_1_1ScriptGroup.html", null ]
    ] ],
    [ "Serialization::Archive::Syncer", "classSerialization_1_1Archive_1_1Syncer.html", null ],
    [ "Serialization::UID", "classSerialization_1_1UID.html", null ],
    [ "DLS::version_t", "structDLS_1_1version__t.html", null ]
];
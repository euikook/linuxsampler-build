var structRIFF_1_1progress__t =
[
    [ "subdivide", "structRIFF_1_1progress__t.html#a930949b134b12cbef6b06b196f9ccfa8", null ],
    [ "subdivide", "structRIFF_1_1progress__t.html#a51031c0fd1a22a8ecf9f4056facc2033", null ],
    [ "__range_max", "structRIFF_1_1progress__t.html#afd8b2cd385d594d261d12adb69a91e87", null ],
    [ "__range_min", "structRIFF_1_1progress__t.html#a11b0d79e77da5f5ab3f28e1ab929abd6", null ],
    [ "callback", "structRIFF_1_1progress__t.html#a95f7e02dfee514f5a7d4cba65d3d2c3d", null ],
    [ "custom", "structRIFF_1_1progress__t.html#ae45708373ce8274c9d00083f8c1482b4", null ],
    [ "factor", "structRIFF_1_1progress__t.html#ab8fa18ac8ddfac8d7cc502f210153cd1", null ]
];
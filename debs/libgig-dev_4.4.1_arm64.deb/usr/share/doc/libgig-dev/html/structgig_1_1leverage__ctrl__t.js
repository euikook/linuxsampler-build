var structgig_1_1leverage__ctrl__t =
[
    [ "type_t", "structgig_1_1leverage__ctrl__t.html#a7da8815e8f32a7c524df6df4f8231d60", [
      [ "type_none", "structgig_1_1leverage__ctrl__t.html#a7da8815e8f32a7c524df6df4f8231d60a0443d97efdcf4ef499f254b6d07ab91d", null ],
      [ "type_channelaftertouch", "structgig_1_1leverage__ctrl__t.html#a7da8815e8f32a7c524df6df4f8231d60aac2cc3ecc9de5c84a46b7c673e0e7d0e", null ],
      [ "type_velocity", "structgig_1_1leverage__ctrl__t.html#a7da8815e8f32a7c524df6df4f8231d60a49d4f6924ac4b2de1a32eceaa1d07cfb", null ],
      [ "type_controlchange", "structgig_1_1leverage__ctrl__t.html#a7da8815e8f32a7c524df6df4f8231d60a539efbbea4daf6f5213ab322e6a5c9ae", null ]
    ] ],
    [ "controller_number", "structgig_1_1leverage__ctrl__t.html#a92ab85b56a06bc66e0abc967afe98cb1", null ],
    [ "type", "structgig_1_1leverage__ctrl__t.html#af45f575df65a065306da887c7707a8bf", null ]
];
var classKorg_1_1KMPRegion =
[
    [ "FilterCutoff", "classKorg_1_1KMPRegion.html#a95ea25cb4c43a5524fd83e804936f24e", null ],
    [ "Level", "classKorg_1_1KMPRegion.html#a6a63593ab02a010d1666a77a660be45a", null ],
    [ "OriginalKey", "classKorg_1_1KMPRegion.html#a72256eca59d7c9401f3ac0113d4465c0", null ],
    [ "Pan", "classKorg_1_1KMPRegion.html#a996f53b8392edaddba37bdf1be756c6e", null ],
    [ "SampleFileName", "classKorg_1_1KMPRegion.html#a067f724bfe12a6ea206c3f38256d61c9", null ],
    [ "TopKey", "classKorg_1_1KMPRegion.html#ac9a181f7437c1c27e908d90a82b2fc97", null ],
    [ "Tune", "classKorg_1_1KMPRegion.html#a25a04b4032f0bc8b1b6a1a0b50d3d052", null ]
];
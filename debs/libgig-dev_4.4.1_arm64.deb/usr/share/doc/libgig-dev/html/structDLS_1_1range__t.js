var structDLS_1_1range__t =
[
    [ "high", "structDLS_1_1range__t.html#a6bb02e8204864623d442ea89412f1738", null ],
    [ "low", "structDLS_1_1range__t.html#a5520215a2b5f0a4ac8117bd4b21e3019", null ]
];
var classDLS_1_1Resource =
[
    [ "Resource", "classDLS_1_1Resource.html#a27ad0dfeb19e6cba4482b46dd6ecdc82", null ],
    [ "CopyAssign", "classDLS_1_1Resource.html#acabeb02d06fe8c9286224bb30859ab75", null ],
    [ "DeleteChunks", "classDLS_1_1Resource.html#a0ce35db83a1bd0e7d9e1d66bc3b206b4", null ],
    [ "GenerateDLSID", "classDLS_1_1Resource.html#acabb2a1f6e02fe9110b4f4cb0319259a", null ],
    [ "UpdateChunks", "classDLS_1_1Resource.html#abd90d13d69cbfaa03640cf22cff8dfea", null ],
    [ "pDLSID", "classDLS_1_1Resource.html#a52632417e3dc96481bdec2b76e18d359", null ],
    [ "pInfo", "classDLS_1_1Resource.html#a34be00ec61a9888c5d0dc67f4c74f33d", null ]
];
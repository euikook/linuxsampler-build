var classSerialization_1_1UID =
[
    [ "isValid", "classSerialization_1_1UID.html#a2e5257c004a17e84c0b230af83671561", null ],
    [ "operator bool", "classSerialization_1_1UID.html#a2a8e9e104e2945f4e8ba15a2389932f7", null ],
    [ "id", "classSerialization_1_1UID.html#ac16f71fb0f048da24c33191476bccf6b", null ],
    [ "size", "classSerialization_1_1UID.html#a61387dbb832688fe9dd697ab292d2657", null ]
];
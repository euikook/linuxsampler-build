var classDLS_1_1Sampler =
[
    [ "AddSampleLoop", "classDLS_1_1Sampler.html#a717d9354651251aa9abec36801f09630", null ],
    [ "CopyAssign", "classDLS_1_1Sampler.html#a22fd47782d302ca179c20d0de5545ab3", null ],
    [ "DeleteChunks", "classDLS_1_1Sampler.html#a037423fcb44d300db7f1f3babb7e5446", null ],
    [ "DeleteSampleLoop", "classDLS_1_1Sampler.html#ad6cd0f66b87d6fe61b8dc8e8392a890b", null ],
    [ "UpdateChunks", "classDLS_1_1Sampler.html#a19cdf2b61f2337735bd73299f9486f02", null ],
    [ "Gain", "classDLS_1_1Sampler.html#aded64bedf4afdf6773e4ba872157c344", null ],
    [ "pSampleLoops", "classDLS_1_1Sampler.html#acb1d8ac5aed3310787e0a960cd82ef04", null ],
    [ "SampleLoops", "classDLS_1_1Sampler.html#a7be8a9078496d44946af3230c2ccc80c", null ]
];
var classSerialization_1_1Exception =
[
    [ "PrintMessage", "classSerialization_1_1Exception.html#af608f483d2365c38ad994f5cf8a0ae81", null ]
];
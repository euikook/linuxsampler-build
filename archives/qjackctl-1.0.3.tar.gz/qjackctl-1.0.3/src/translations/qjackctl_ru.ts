<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru" sourcelanguage="en">
<context>
    <name>PortAudioProber</name>
    <message>
        <location filename="../qjackctlInterfaceComboBox.cpp" line="156"/>
        <source>Probing...</source>
        <translation>Опрос…</translation>
    </message>
    <message>
        <location filename="../qjackctlInterfaceComboBox.cpp" line="157"/>
        <source>Please wait, PortAudio is probing audio hardware.</source>
        <translation>Подождите немного, PortAudio опрашивает звуковой интерфейс.</translation>
    </message>
    <message>
        <location filename="../qjackctlInterfaceComboBox.cpp" line="191"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../qjackctlInterfaceComboBox.cpp" line="192"/>
        <source>Audio hardware probing timed out.</source>
        <translation>Время опроса звукового интерфейса истекло.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../qjackctlSetup.cpp" line="685"/>
        <location filename="../qjackctlSetup.cpp" line="747"/>
        <source>Option -p requires an argument (preset).</source>
        <translation>Ключ -p требует аргумента (профиль параметров).</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="58"/>
        <source>(default)</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/38</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="631"/>
        <source>Usage: %1 [options] [command-and-args]</source>
        <translation>Использование: %1 [ключи] [команды-и-аргументы]</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="634"/>
        <source>Options:</source>
        <translation>Ключи:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="636"/>
        <location filename="../qjackctlSetup.cpp" line="664"/>
        <source>Start JACK audio server immediately.</source>
        <translation>Запустить звуковой сервер JACK немедленно.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="638"/>
        <location filename="../qjackctlSetup.cpp" line="666"/>
        <source>Set default settings preset name.</source>
        <translation>Указать имя профиля параметров по умолчанию.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="640"/>
        <location filename="../qjackctlSetup.cpp" line="668"/>
        <source>Set active patchbay definition file.</source>
        <translation>Установить файл активного описания коммутатора.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="642"/>
        <location filename="../qjackctlSetup.cpp" line="670"/>
        <source>Set default JACK audio server name.</source>
        <translation>Указать имя звукового сервера JACK по умолчанию.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="644"/>
        <source>Show help about command line options.</source>
        <translation>Показать справку о ключах командной строки.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="646"/>
        <source>Show version information.</source>
        <translation>Показать сведения о версии.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="674"/>
        <source>Launch command with arguments.</source>
        <translation>Запустить команду с аргументами.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="675"/>
        <source>[command-and-args]</source>
        <translation>[команда-и-аргументы]</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="694"/>
        <location filename="../qjackctlSetup.cpp" line="756"/>
        <source>Option -a requires an argument (path).</source>
        <translation>Ключу -a необходим аргумент (расположение).</translation>
    </message>
    <message>
        <location filename="../qjackctlSetup.cpp" line="704"/>
        <location filename="../qjackctlSetup.cpp" line="766"/>
        <source>Option -n requires an argument (name).</source>
        <translation>Ключу -n необходим аргумент (название).</translation>
    </message>
    <message>
        <location filename="../qjackctlJackConnect.cpp" line="178"/>
        <source>%1 (%2 frames)</source>
        <translation>%1 (%2 выб.)</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphCommand.cpp" line="130"/>
        <source>Move</source>
        <translation>Переместить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphCommand.cpp" line="217"/>
        <source>Rename</source>
        <translation>Переименовать</translation>
    </message>
</context>
<context>
    <name>qjackctlAboutForm</name>
    <message>
        <location filename="../qjackctlAboutForm.ui" line="37"/>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.ui" line="87"/>
        <source>About Qt</source>
        <translation>О Qt</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.ui" line="77"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="87"/>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="52"/>
        <source>Transport status control disabled.</source>
        <translation>Управление состоянием передачи отключено.</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="55"/>
        <source>Realtime status disabled.</source>
        <translation>Статус режима реального времени отключён.</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="70"/>
        <source>JACK Session support disabled.</source>
        <translation>Поддержка JACK Session отключена.</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="95"/>
        <source>Using: Qt %1</source>
        <translation>Использует: Qt %1</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="101"/>
        <source>JACK %1</source>
        <translation>JACK %1</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="105"/>
        <source>Website</source>
        <translation>Домашняя страница</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="110"/>
        <source>This program is free software; you can redistribute it and/or modify it</source>
        <translation>Это программа является свободной; вы можете распространять 
и/или изменять её без ограничений</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="111"/>
        <source>under the terms of the GNU General Public License version 2 or later.</source>
        <translation>на условиях лицензии GNU General Public License версии 2 или более новой.</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="46"/>
        <source>Debugging option enabled.</source>
        <translation>Параметр отладки включён.</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="49"/>
        <source>System tray disabled.</source>
        <translation>Область уведомления отключена.</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="58"/>
        <source>XRUN delay status disabled.</source>
        <translation>Статус задержки XRUN отключён.</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="61"/>
        <source>Maximum delay status disabled.</source>
        <translation>Статус максимальной задержки отключён.</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="67"/>
        <source>JACK MIDI support disabled.</source>
        <translation>Поддержка JACK MIDI отключена.</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="74"/>
        <source>ALSA/MIDI sequencer support disabled.</source>
        <translation>Поддержка секвенсера ALSA/MIDI отключена.</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="64"/>
        <source>JACK Port aliases support disabled.</source>
        <translation>Поддержка алиасов портов JACK отключена.</translation>
    </message>
    <message>
        <location filename="../qjackctlAboutForm.cpp" line="79"/>
        <source>D-Bus interface support disabled.</source>
        <translation>Поддержка интерфейса D-Bus отключена.</translation>
    </message>
</context>
<context>
    <name>qjackctlApplication</name>
    <message>
        <location filename="../qjackctl.cpp" line="142"/>
        <source>JACK: %1</source>
        <translation>JACK: %1</translation>
    </message>
</context>
<context>
    <name>qjackctlClientListView</name>
    <message>
        <location filename="../qjackctlConnect.cpp" line="797"/>
        <source>Readable Clients / Output Ports</source>
        <translation>Порты выхода</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="799"/>
        <source>Writable Clients / Input Ports</source>
        <translation>Порты входа</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1112"/>
        <location filename="../qjackctlConnect.cpp" line="1137"/>
        <source>&amp;Connect</source>
        <translation>&amp;Соединить</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1112"/>
        <location filename="../qjackctlConnect.cpp" line="1138"/>
        <source>Alt+C</source>
        <comment>Connect</comment>
        <translation>Alt+с</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1116"/>
        <location filename="../qjackctlConnect.cpp" line="1141"/>
        <source>&amp;Disconnect</source>
        <translation>&amp;Отсоединить</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1116"/>
        <location filename="../qjackctlConnect.cpp" line="1142"/>
        <source>Alt+D</source>
        <comment>Disconnect</comment>
        <translation>Alt+р</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1120"/>
        <location filename="../qjackctlConnect.cpp" line="1145"/>
        <source>Disconnect &amp;All</source>
        <translation>Отсоединить &amp;все</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1120"/>
        <location filename="../qjackctlConnect.cpp" line="1146"/>
        <source>Alt+A</source>
        <comment>Disconnect All</comment>
        <translation>Alt+в</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1126"/>
        <location filename="../qjackctlConnect.cpp" line="1151"/>
        <source>Re&amp;name</source>
        <translation>Пере&amp;именовать</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1126"/>
        <location filename="../qjackctlConnect.cpp" line="1152"/>
        <source>Alt+N</source>
        <comment>Rename</comment>
        <translation>Alt+и</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1133"/>
        <location filename="../qjackctlConnect.cpp" line="1158"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Обновить</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1133"/>
        <location filename="../qjackctlConnect.cpp" line="1159"/>
        <source>Alt+R</source>
        <comment>Refresh</comment>
        <translation>Alt+о</translation>
    </message>
</context>
<context>
    <name>qjackctlConnect</name>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1986"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1987"/>
        <source>This will suspend sound processing
from all client applications.

Are you sure?</source>
        <translation>Обработка звука от клиентских
приложений будет прекращена.

Вы уверены?</translation>
    </message>
</context>
<context>
    <name>qjackctlConnectionsForm</name>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="101"/>
        <location filename="../qjackctlConnectionsForm.ui" line="236"/>
        <location filename="../qjackctlConnectionsForm.ui" line="371"/>
        <source>&amp;Connect</source>
        <translation>&amp;Соединить</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="98"/>
        <location filename="../qjackctlConnectionsForm.ui" line="233"/>
        <location filename="../qjackctlConnectionsForm.ui" line="368"/>
        <source>Connect currently selected ports</source>
        <translation>Соединить выбранные сейчас порты</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="114"/>
        <location filename="../qjackctlConnectionsForm.ui" line="249"/>
        <location filename="../qjackctlConnectionsForm.ui" line="384"/>
        <source>&amp;Disconnect</source>
        <translation>&amp;Отсоединить</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="111"/>
        <location filename="../qjackctlConnectionsForm.ui" line="246"/>
        <location filename="../qjackctlConnectionsForm.ui" line="381"/>
        <source>Disconnect currently selected ports</source>
        <translation>Отсоединить выбранные сейчас порты</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="127"/>
        <location filename="../qjackctlConnectionsForm.ui" line="262"/>
        <location filename="../qjackctlConnectionsForm.ui" line="397"/>
        <source>Disconnect &amp;All</source>
        <translation>Отсоединить &amp;все</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="124"/>
        <location filename="../qjackctlConnectionsForm.ui" line="259"/>
        <location filename="../qjackctlConnectionsForm.ui" line="394"/>
        <source>Disconnect all currently connected ports</source>
        <translation>Отсоединить все соединённые сейчас порты</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="44"/>
        <source>Connections</source>
        <translation>Соединения</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="153"/>
        <location filename="../qjackctlConnectionsForm.ui" line="288"/>
        <location filename="../qjackctlConnectionsForm.ui" line="423"/>
        <source>Expand all client ports</source>
        <translation>Раскрыть все порты клиентов</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="156"/>
        <location filename="../qjackctlConnectionsForm.ui" line="291"/>
        <location filename="../qjackctlConnectionsForm.ui" line="426"/>
        <source>E&amp;xpand All</source>
        <translation>&amp;Раскрыть все</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="185"/>
        <location filename="../qjackctlConnectionsForm.ui" line="320"/>
        <location filename="../qjackctlConnectionsForm.ui" line="455"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Обновить</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="182"/>
        <location filename="../qjackctlConnectionsForm.ui" line="317"/>
        <location filename="../qjackctlConnectionsForm.ui" line="452"/>
        <source>Refresh current connections view</source>
        <translation>Обновить отображение текущих соединений</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="63"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="198"/>
        <source>MIDI</source>
        <translation>MIDI</translation>
    </message>
    <message>
        <location filename="../qjackctlConnectionsForm.ui" line="333"/>
        <source>ALSA</source>
        <translation>ALSA</translation>
    </message>
</context>
<context>
    <name>qjackctlConnectorView</name>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1340"/>
        <location filename="../qjackctlConnect.cpp" line="1357"/>
        <source>&amp;Connect</source>
        <translation>&amp;Соединить</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1340"/>
        <location filename="../qjackctlConnect.cpp" line="1358"/>
        <source>Alt+C</source>
        <comment>Connect</comment>
        <translation>Alt+с</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1344"/>
        <location filename="../qjackctlConnect.cpp" line="1361"/>
        <source>&amp;Disconnect</source>
        <translation>&amp;Отсоединить</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1344"/>
        <location filename="../qjackctlConnect.cpp" line="1362"/>
        <source>Alt+D</source>
        <comment>Disconnect</comment>
        <translation>Alt+р</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1348"/>
        <location filename="../qjackctlConnect.cpp" line="1365"/>
        <source>Disconnect &amp;All</source>
        <translation>Отсоединить &amp;все</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1348"/>
        <location filename="../qjackctlConnect.cpp" line="1366"/>
        <source>Alt+A</source>
        <comment>Disconnect All</comment>
        <translation>Alt+в</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1353"/>
        <location filename="../qjackctlConnect.cpp" line="1370"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Обновить</translation>
    </message>
    <message>
        <location filename="../qjackctlConnect.cpp" line="1353"/>
        <location filename="../qjackctlConnect.cpp" line="1371"/>
        <source>Alt+R</source>
        <comment>Refresh</comment>
        <translation>Alt+о</translation>
    </message>
</context>
<context>
    <name>qjackctlGraphCanvas</name>
    <message>
        <location filename="../qjackctlGraph.cpp" line="1907"/>
        <location filename="../qjackctlGraph.cpp" line="2048"/>
        <source>Connect</source>
        <translation>Соединить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraph.cpp" line="2120"/>
        <source>Disconnect</source>
        <translation>Отсоединить</translation>
    </message>
</context>
<context>
    <name>qjackctlGraphForm</name>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="33"/>
        <source>Graph</source>
        <translation>Граф</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="63"/>
        <source>&amp;Graph</source>
        <translation>&amp;Граф</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="72"/>
        <source>&amp;Edit</source>
        <translation>&amp;Правка</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="83"/>
        <source>&amp;View</source>
        <translation>&amp;Вид</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="101"/>
        <source>&amp;Zoom</source>
        <translation>&amp;Масштаб</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="114"/>
        <source>Co&amp;lors</source>
        <translation>&amp;Цвета</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="126"/>
        <source>S&amp;ort</source>
        <translation>&amp;Сортировка</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="156"/>
        <source>&amp;Help</source>
        <translation>&amp;Справка</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="204"/>
        <source>&amp;Connect</source>
        <translation>&amp;Соединить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="207"/>
        <location filename="../qjackctlGraphForm.ui" line="210"/>
        <source>Connect</source>
        <translation>Соединить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="213"/>
        <source>Connect selected ports</source>
        <translation>Соединить выбранные порты</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="224"/>
        <source>&amp;Disconnect</source>
        <translation>&amp;Отсоединить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="227"/>
        <location filename="../qjackctlGraphForm.ui" line="230"/>
        <source>Disconnect</source>
        <translation>Отсоединить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="233"/>
        <source>Disconnect selected ports</source>
        <translation>Отсоединить выбранные порты</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="216"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="87"/>
        <source>T&amp;humbview</source>
        <translation>М&amp;иниатюра</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="236"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="241"/>
        <source>Cl&amp;ose</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="244"/>
        <location filename="../qjackctlGraphForm.ui" line="247"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="250"/>
        <source>Close this application window</source>
        <translation>Закрыть это окно приложения</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="258"/>
        <source>Select &amp;All</source>
        <translation>Выбрать &amp;все</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="261"/>
        <location filename="../qjackctlGraphForm.ui" line="264"/>
        <location filename="../qjackctlGraphForm.ui" line="267"/>
        <source>Select All</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="270"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="275"/>
        <source>Select &amp;None</source>
        <translation>Снять в&amp;ыделение</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="278"/>
        <location filename="../qjackctlGraphForm.ui" line="281"/>
        <location filename="../qjackctlGraphForm.ui" line="284"/>
        <source>Select None</source>
        <translation>Снять выделение</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="287"/>
        <source>Ctrl+Shift+A</source>
        <translation>Ctrl+Shift+A</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="292"/>
        <source>Select &amp;Invert</source>
        <translation>&amp;Инвертировать выделение</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="295"/>
        <location filename="../qjackctlGraphForm.ui" line="298"/>
        <location filename="../qjackctlGraphForm.ui" line="301"/>
        <source>Select Invert</source>
        <translation>Инвертировать выделение</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="304"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="312"/>
        <source>&amp;Rename...</source>
        <translation>Пере&amp;именовать...</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="315"/>
        <source>Rename item</source>
        <translation>Переименовать объект</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="318"/>
        <location filename="../qjackctlGraphForm.ui" line="321"/>
        <source>Rename Item</source>
        <translation>Переименовать объект</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="324"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="332"/>
        <source>&amp;Find...</source>
        <translation>&amp;Найти…</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="335"/>
        <source>Find</source>
        <translation>Найти</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="338"/>
        <location filename="../qjackctlGraphForm.ui" line="341"/>
        <source>Find nodes</source>
        <translation>Найти узлы</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="344"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="352"/>
        <source>&amp;Menubar</source>
        <translation>Панель &amp;меню</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="355"/>
        <location filename="../qjackctlGraphForm.ui" line="358"/>
        <source>Menubar</source>
        <translation>Панель меню</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="361"/>
        <source>Show/hide the main program window menubar</source>
        <translation>Показать/скрыть панель меню программы</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="364"/>
        <source>Ctrl+M</source>
        <translation>Ctrl+M</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="372"/>
        <source>&amp;Toolbar</source>
        <translation>Панель &amp;инструментов</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="375"/>
        <location filename="../qjackctlGraphForm.ui" line="378"/>
        <source>Toolbar</source>
        <translation>Панель инструментов</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="381"/>
        <source>Show/hide main program window file toolbar</source>
        <translation>Показать/скрыть панель инструментов программы</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="389"/>
        <source>&amp;Statusbar</source>
        <translation>&amp;Статусная строка</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="392"/>
        <location filename="../qjackctlGraphForm.ui" line="395"/>
        <source>Statusbar</source>
        <translation>Статусная строка</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="398"/>
        <source>Show/hide the main program window statusbar</source>
        <translation>Показать/скрыть статусную строку программы</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="409"/>
        <source>&amp;Top Left</source>
        <translation>&amp;Вверху слева</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="412"/>
        <location filename="../qjackctlGraphForm.ui" line="415"/>
        <source>Top left</source>
        <translation>Вверху слева</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="418"/>
        <source>Show the thumbnail overview on the top-left</source>
        <translation>Показывать обзор миниатюр вверху слева</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="429"/>
        <source>Top &amp;Right</source>
        <translation>Вверху &amp;справа</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="432"/>
        <location filename="../qjackctlGraphForm.ui" line="435"/>
        <source>Top right</source>
        <translation>Вверху справа</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="438"/>
        <source>Show the thumbnail overview on the top-right</source>
        <translation>Показывать обзор миниатюр вверху справа</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="449"/>
        <source>Bottom &amp;Left</source>
        <translation>&amp;Внизу слева</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="452"/>
        <source>Bottom Left</source>
        <translation>Внизу слева</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="455"/>
        <source>Bottom left</source>
        <translation>Внизу слева</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="458"/>
        <source>Show the thumbnail overview on the bottom-left</source>
        <translation>Показывать обзор миниатюр внизу слева</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="469"/>
        <source>&amp;Bottom Right</source>
        <translation>&amp;Внизу справа</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="472"/>
        <location filename="../qjackctlGraphForm.ui" line="475"/>
        <source>Bottom right</source>
        <translation>Внизу справа</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="478"/>
        <source>Show the thumbnail overview on the bottom-right</source>
        <translation>Показывать обзор миниатюр внизу справа</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="489"/>
        <source>&amp;None</source>
        <translation>&amp;Нет</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="492"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="495"/>
        <source>Hide thumbview</source>
        <translation>Не показывать миниатюру</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="498"/>
        <source>Hide the thumbnail overview</source>
        <translation>Не показывать обзор миниатюр</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="509"/>
        <source>Text Beside &amp;Icons</source>
        <translation>Текст &amp;рядом со значками</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="512"/>
        <location filename="../qjackctlGraphForm.ui" line="515"/>
        <source>Text beside icons</source>
        <translation>Текст рядом со значками</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="518"/>
        <source>Show/hide text beside icons</source>
        <translation>Показывать или скрывать текст рядом со значками</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="526"/>
        <source>&amp;Center</source>
        <translation>&amp;Центрировать</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="529"/>
        <location filename="../qjackctlGraphForm.ui" line="532"/>
        <source>Center</source>
        <translation>Центрировать</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="535"/>
        <source>Center view</source>
        <translation>Центрировать вид</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="543"/>
        <source>&amp;Refresh</source>
        <translation>О&amp;бновить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="546"/>
        <location filename="../qjackctlGraphForm.ui" line="549"/>
        <source>Refresh</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="552"/>
        <source>Refresh view</source>
        <translation>Обновить вид</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="555"/>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="563"/>
        <source>Zoom &amp;In</source>
        <translation>&amp;Приблизить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="566"/>
        <location filename="../qjackctlGraphForm.ui" line="569"/>
        <location filename="../qjackctlGraphForm.ui" line="572"/>
        <source>Zoom In</source>
        <translation>Приблизить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="575"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="583"/>
        <source>Zoom &amp;Out</source>
        <translation>От&amp;далить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="586"/>
        <location filename="../qjackctlGraphForm.ui" line="589"/>
        <location filename="../qjackctlGraphForm.ui" line="592"/>
        <source>Zoom Out</source>
        <translation>Отдалить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="595"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="603"/>
        <source>Zoom &amp;Fit</source>
        <translation>Уместить вс&amp;ё в окне</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="606"/>
        <location filename="../qjackctlGraphForm.ui" line="609"/>
        <location filename="../qjackctlGraphForm.ui" line="612"/>
        <source>Zoom Fit</source>
        <translation>Уместить всё в окне</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="615"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="623"/>
        <source>Zoom &amp;Reset</source>
        <translation>Сбросить &amp;масштаб</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="626"/>
        <location filename="../qjackctlGraphForm.ui" line="629"/>
        <location filename="../qjackctlGraphForm.ui" line="632"/>
        <source>Zoom Reset</source>
        <translation>Сбросить масштаб</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="635"/>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="646"/>
        <source>&amp;Zoom Range</source>
        <translation>Приблизить в&amp;ыделенное</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="649"/>
        <location filename="../qjackctlGraphForm.ui" line="652"/>
        <location filename="../qjackctlGraphForm.ui" line="655"/>
        <source>Zoom Range</source>
        <translation>Приблизить выделенное</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="663"/>
        <source>JACK &amp;Audio...</source>
        <translation>JACK &amp;Audio...</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="666"/>
        <location filename="../qjackctlGraphForm.ui" line="669"/>
        <location filename="../qjackctlGraphForm.ui" line="672"/>
        <source>JACK Audio color</source>
        <translation>Цвет JACK Audio</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="680"/>
        <source>JACK &amp;MIDI...</source>
        <translation>JACK &amp;MIDI...</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="683"/>
        <source>JACK MIDI</source>
        <translation>JACK MIDI</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="686"/>
        <location filename="../qjackctlGraphForm.ui" line="689"/>
        <source>JACK MIDI color</source>
        <translation>Цвет JACK MIDI</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="697"/>
        <source>ALSA M&amp;IDI...</source>
        <translation>ALSA M&amp;IDI...</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="700"/>
        <source>ALSA MIDI</source>
        <translation>ALSA MIDI</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="703"/>
        <location filename="../qjackctlGraphForm.ui" line="706"/>
        <source>ALSA MIDI color</source>
        <translation>Цвет ALSA MIDI</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="714"/>
        <source>JACK &amp;CV...</source>
        <translation>JACK &amp;CV...</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="717"/>
        <location filename="../qjackctlGraphForm.ui" line="720"/>
        <location filename="../qjackctlGraphForm.ui" line="723"/>
        <source>JACK CV color</source>
        <translation>Цвет JACK CV</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="731"/>
        <source>JACK &amp;OSC...</source>
        <translation>JACK &amp;OSC...</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="734"/>
        <source>JACK OSC</source>
        <translation>JACK OSC</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="737"/>
        <location filename="../qjackctlGraphForm.ui" line="740"/>
        <source>JACK OSC color</source>
        <translation>Цвет JACK OSC</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="748"/>
        <source>&amp;Reset</source>
        <translation>С&amp;бросить</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="751"/>
        <location filename="../qjackctlGraphForm.ui" line="754"/>
        <location filename="../qjackctlGraphForm.ui" line="757"/>
        <source>Reset colors</source>
        <translation>Сбросить цвета</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="768"/>
        <source>Port &amp;Name</source>
        <translation>По &amp;названию порта</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="771"/>
        <source>Port name</source>
        <translation>Название порта</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="774"/>
        <source>Sort by port name</source>
        <translation>Сортировать по названию порта</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="785"/>
        <source>Port &amp;Title</source>
        <translation>По &amp;заголовку порта</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="788"/>
        <source>Port title</source>
        <translation>По заголовку порта</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="791"/>
        <source>Sort by port title</source>
        <translation>Сортировать по заголовку порта</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="802"/>
        <source>Port &amp;Index</source>
        <translation>По &amp;индексу порта</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="805"/>
        <source>Port index</source>
        <translation>По индексу порта</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="808"/>
        <source>Sort by port index</source>
        <translation>Сортировать по индексу порта</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="819"/>
        <source>&amp;Ascending</source>
        <translation>По &amp;нарастанию</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="822"/>
        <source>Ascending</source>
        <translation>По нарастанию</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="825"/>
        <source>Ascending sort order</source>
        <translation>Порядок сортировки по нарастанию</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="836"/>
        <source>&amp;Descending</source>
        <translation>По &amp;убыванию</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="839"/>
        <source>Descending</source>
        <translation>По убыванию</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="842"/>
        <source>Descending sort order</source>
        <translation>Порядок сортировки по убыванию</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="853"/>
        <source>Repel O&amp;verlapping Nodes</source>
        <translation>Отбросить п&amp;ерекрывающиеся узлы</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="856"/>
        <source>Repel nodes</source>
        <translation>Отбросить узлы</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="859"/>
        <location filename="../qjackctlGraphForm.ui" line="862"/>
        <source>Repel overlapping nodes</source>
        <translation>Отбросить перекрывающиеся узлы</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="873"/>
        <source>Connect Thro&amp;ugh Nodes</source>
        <translation>Соединение чер&amp;ез узлы</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="876"/>
        <source>Connect Through Nodes</source>
        <translation>Соединение через узлы</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="879"/>
        <source>Connect through nodes</source>
        <translation>Соединение через узлы</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="882"/>
        <source>Whether to draw connectors through or around nodes</source>
        <translation>Определяет, проводить ли соединительные элементы через узлы или вокруг них</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="890"/>
        <source>&amp;About...</source>
        <translation>&amp;О программе...</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="893"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="896"/>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="899"/>
        <source>Show information about this application program</source>
        <translation>Показать информацию об этой программе</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="907"/>
        <source>About &amp;Qt...</source>
        <translation>О &amp;Qt...</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="910"/>
        <source>About Qt...</source>
        <translation>О Qt...</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="913"/>
        <source>About Qt</source>
        <translation>О Qt</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.ui" line="916"/>
        <source>Show information about the Qt toolkit</source>
        <translation>Показать информацию о наборе инструментов Qt</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.cpp" line="102"/>
        <source>&amp;Undo</source>
        <translation>&amp;Отмена</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.cpp" line="107"/>
        <source>&amp;Redo</source>
        <translation>&amp;Возврат</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.cpp" line="104"/>
        <source>Undo last edit action</source>
        <translation>Отменить последнее действие</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.cpp" line="109"/>
        <source>Redo last edit action</source>
        <translation>Вернуть последнее действие</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.cpp" line="125"/>
        <source>Zoom</source>
        <translation>Масштаб</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.cpp" line="510"/>
        <source>Ready</source>
        <translation>Готово</translation>
    </message>
    <message>
        <location filename="../qjackctlGraphForm.cpp" line="654"/>
        <source>Colors - %1</source>
        <translation>Цвета — %1</translation>
    </message>
</context>
<context>
    <name>qjackctlMainForm</name>
    <message>
        <location filename="../qjackctlMainForm.ui" line="63"/>
        <location filename="../qjackctlMainForm.cpp" line="4138"/>
        <source>&amp;Start</source>
        <translation>&amp;Запустить</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="60"/>
        <source>Start the JACK server</source>
        <translation>Запустить сервер JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="97"/>
        <source>S&amp;top</source>
        <translation>С&amp;топ</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="94"/>
        <source>Stop the JACK server</source>
        <translation>Остановить сервер JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="390"/>
        <location filename="../qjackctlMainForm.cpp" line="595"/>
        <location filename="../qjackctlMainForm.cpp" line="4278"/>
        <source>&amp;Quit</source>
        <translation>В&amp;ыход</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="387"/>
        <source>Quit processing and exit</source>
        <translation>Остановить сервер и выйти из программы</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1688"/>
        <source>JACK is starting...</source>
        <translation>Выполняется запуск JACK...</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1768"/>
        <source>JACK is stopping...</source>
        <translation>Выполняется остановка JACK...</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2751"/>
        <source>msec</source>
        <translation>мс</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2134"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="145"/>
        <source>JACK server state</source>
        <translation>Состояние сервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="220"/>
        <source>Sample rate</source>
        <translation>Частота сэмплирования</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="273"/>
        <source>Time display</source>
        <translation>Время</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="300"/>
        <source>Transport state</source>
        <translation>Состояние передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="327"/>
        <source>Transport BPM</source>
        <translation>BPM передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="353"/>
        <source>Transport time</source>
        <translation>Время передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="684"/>
        <location filename="../qjackctlMainForm.cpp" line="4256"/>
        <source>&amp;Play</source>
        <translation>&amp;Воспроизвести</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="681"/>
        <source>Start transport rolling</source>
        <translation>Запустить прокрутку передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="715"/>
        <location filename="../qjackctlMainForm.cpp" line="4259"/>
        <source>Pa&amp;use</source>
        <translation>Пау&amp;за</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="712"/>
        <source>Stop transport rolling</source>
        <translation>Остановить прокрутку передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4229"/>
        <source>St&amp;atus</source>
        <translation>С&amp;татус</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="774"/>
        <location filename="../qjackctlMainForm.cpp" line="603"/>
        <location filename="../qjackctlMainForm.cpp" line="4273"/>
        <source>Ab&amp;out...</source>
        <translation>О про&amp;грамме...</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="771"/>
        <source>Show information about this application</source>
        <translation>Показать информацию о приложении</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="486"/>
        <source>Show settings and options dialog</source>
        <translation>Показать диалог настройки программы</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="455"/>
        <location filename="../qjackctlMainForm.cpp" line="4223"/>
        <source>&amp;Messages</source>
        <translation>С&amp;ообщения</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4243"/>
        <source>Patch&amp;bay</source>
        <translation>&amp;Коммутатор</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="588"/>
        <source>Show/hide the patchbay editor window</source>
        <translation>Показать/скрыть окно коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4239"/>
        <source>&amp;Connections</source>
        <translation>Сое&amp;динения</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1311"/>
        <source>successfully</source>
        <translation>успешно</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4008"/>
        <source>Activating</source>
        <translation>Активируется</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3706"/>
        <location filename="../qjackctlMainForm.cpp" line="3847"/>
        <location filename="../qjackctlMainForm.cpp" line="3991"/>
        <source>Starting</source>
        <translation>Запуск</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="961"/>
        <source>The program will keep running in the system tray.

To terminate the program, please choose &quot;Quit&quot;
in the context menu of the system tray icon.</source>
        <translation>Программа продолжит работать в области уведомления.

Для завершения выберите в контекстном меню
области уведомления пункт «Выход».</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1440"/>
        <source>Startup script...</source>
        <translation>Сценарий запуска...</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1441"/>
        <source>Startup script terminated</source>
        <translation>Выполнение сценария запуска прекращено</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3995"/>
        <source>Started</source>
        <translation>Запущен</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3722"/>
        <location filename="../qjackctlMainForm.cpp" line="3998"/>
        <source>Stopping</source>
        <translation>Остановка</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1936"/>
        <source>JACK was stopped</source>
        <translation>Cервер JACK остановлен</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1761"/>
        <source>Shutdown script...</source>
        <translation>Сценарий выключения...</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1762"/>
        <source>Shutdown script terminated</source>
        <translation>Выполнение сценария выключения прекращено</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4013"/>
        <source>Inactive</source>
        <translation>Не активен</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4005"/>
        <source>Active</source>
        <translation>Активен</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3762"/>
        <location filename="../qjackctlMainForm.cpp" line="4002"/>
        <source>Stopped</source>
        <translation>Остановлен</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2508"/>
        <source>Could not load active patchbay definition.

&quot;%1&quot;

Disabled.</source>
        <translation>Не удалось загрузить описание активного коммутатора.

«%1»

Отключено.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2612"/>
        <source>Statistics reset.</source>
        <translation>Перезапуск статистики</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2817"/>
        <source>Shutdown notification.</source>
        <translation>Уведомление об остановке</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3019"/>
        <source>checked</source>
        <translation>проверено</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3023"/>
        <source>connected</source>
        <translation>соединено</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3032"/>
        <source>failed</source>
        <translation>не удалось</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3328"/>
        <source>Client activated.</source>
        <translation>Клиент активирован</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3339"/>
        <source>Post-startup script...</source>
        <translation>Сценарий после запуска...</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3340"/>
        <source>Post-startup script terminated</source>
        <translation>Выполнение сценария после запуска прекращено</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3371"/>
        <source>Client deactivated.</source>
        <translation>Клиент деактивирован</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3708"/>
        <source>Transport start.</source>
        <translation>Передача запущена</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3724"/>
        <source>Transport stop.</source>
        <translation>Передача остановлена</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3832"/>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3832"/>
        <source>No</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3850"/>
        <source>Rolling</source>
        <translation>Прокрутка</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3853"/>
        <source>Looping</source>
        <translation>Цикл</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2282"/>
        <source>Transport time code</source>
        <translation>Тайм-код передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2293"/>
        <source>Elapsed time since last reset</source>
        <translation>Времени с последней перезагрузки</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2296"/>
        <source>Elapsed time since last XRUN</source>
        <translation>Времени с последнего XRUN</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3027"/>
        <source>disconnected</source>
        <translation>отсоединено</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3348"/>
        <source>Command line argument...</source>
        <translation>Аргумент командной строки...</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3349"/>
        <source>Command line argument started</source>
        <translation>Аргумент командной строки запущен</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="959"/>
        <location filename="../qjackctlMainForm.cpp" line="4286"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1150"/>
        <source>Do you want to restart the JACK audio server?</source>
        <translation>Перезапустить звуковой сервер JACK?</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4288"/>
        <source>Some settings will be only effective
the next time you start this program.</source>
        <translation>Некоторые изменения вступят в силу
только при следующем запуске программы.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="172"/>
        <source>JACK server mode</source>
        <translation>Режим сервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1144"/>
        <source>Server settings will be only effective after
restarting the JACK audio server.</source>
        <translation>Параметры работы сервера JACK вступят в силу
только при следующем запуске сервера.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3840"/>
        <source>RT</source>
        <translation>RT</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4128"/>
        <location filename="../qjackctlMainForm.cpp" line="4183"/>
        <source>&amp;Hide</source>
        <translation>С&amp;крыть</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4129"/>
        <location filename="../qjackctlMainForm.cpp" line="4183"/>
        <source>S&amp;how</source>
        <translation>&amp;Показать</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4141"/>
        <source>&amp;Stop</source>
        <translation>&amp;Стоп</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="836"/>
        <source>Could not open ALSA sequencer as a client.

ALSA MIDI patchbay will be not available.</source>
        <translation>Не удалось открыть секвенсер ALSA как клиентское приложение.

Коммутатор ALSA MIDI будет недоступен.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2427"/>
        <source>D-BUS: Service is available (%1 aka jackdbus).</source>
        <translation>D-BUS: служба доступна (%1, известный как jackdbus).</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2458"/>
        <source>D-BUS: Service not available (%1 aka jackdbus).</source>
        <translation>D-BUS: служба недоступна (%1, известный как jackdbus).</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1001"/>
        <location filename="../qjackctlMainForm.cpp" line="1108"/>
        <location filename="../qjackctlMainForm.cpp" line="1142"/>
        <location filename="../qjackctlMainForm.cpp" line="1200"/>
        <location filename="../qjackctlMainForm.cpp" line="1359"/>
        <location filename="../qjackctlMainForm.cpp" line="3089"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1009"/>
        <source>JACK is currently running.

Do you want to terminate the JACK audio server?</source>
        <translation>Сервер JACK работает.

Вы хотите остановить его?</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1024"/>
        <location filename="../qjackctlMainForm.cpp" line="1160"/>
        <location filename="../qjackctlMainForm.cpp" line="1213"/>
        <location filename="../qjackctlMainForm.cpp" line="3106"/>
        <source>Don&apos;t ask this again</source>
        <translation>Больше не спрашивать</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1313"/>
        <source>with exit status=%1</source>
        <translation>со статусом выхода %1</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1360"/>
        <source>Could not start JACK.

Maybe JACK audio server is already started.</source>
        <translation>Не удалось запустить JACK.

Возможно, звуковой сервер уже запущен.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1403"/>
        <source>Could not load preset &quot;%1&quot;.

Retrying with default.</source>
        <translation>Не удалось загрузить профиль «%1».

Попытка загрузить используемый по умолчанию профиль.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1406"/>
        <source>Could not load default preset.

Sorry.</source>
        <translation>Не удалось запустить профиль по умолчанию.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1456"/>
        <source>D-BUS: JACK server is starting...</source>
        <translation>D-BUS: запускается сервер JACK...</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1459"/>
        <source>D-BUS: JACK server could not be started.

Sorry</source>
        <translation>D-BUS: не удалось запустить сервер JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1202"/>
        <source>Some client audio applications
are still active and connected.

Do you want to stop the JACK audio server?</source>
        <translation>Некоторые клиентские звуковые приложения
всё ещё активны и подсоединены.

Остановить звуковой сервер JACK?</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1784"/>
        <source>D-BUS: JACK server is stopping...</source>
        <translation>D-BUS: сервер JACK останавливается...</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1787"/>
        <source>D-BUS: JACK server could not be stopped.

Sorry</source>
        <translation>D-BUS: не удалось остановить сервер JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1964"/>
        <source>Post-shutdown script...</source>
        <translation>Выполняется сценарий после выключения…</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1965"/>
        <source>Post-shutdown script terminated</source>
        <translation>Выполнение сценария после выключения прекращено</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1874"/>
        <source>JACK was started with PID=%1.</source>
        <translation>JACK был запущен с PID=%1.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="978"/>
        <source>Don&apos;t show this message again</source>
        <translation>Больше не показывать это сообщение</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1109"/>
        <source>The preset aliases have been changed:

&quot;%1&quot;

Do you want to save the changes?</source>
        <translation>Алиасы профилей изменились:

«%1»

Сохранить изменения?</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1886"/>
        <source>D-BUS: JACK server was started (%1 aka jackdbus).</source>
        <translation>D-BUS: сервер JACK был запущен (%1, известный как jackdbus).</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1926"/>
        <source>JACK is being forced...</source>
        <translation>Принудительное выполнение JACK…</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1949"/>
        <source>D-BUS: JACK server was stopped (%1 aka jackdbus).</source>
        <translation>D-BUS: сервер JACK был остановлен (%1, известный как jackdbus).</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2281"/>
        <source>Transport BBT (bar.beat.ticks)</source>
        <translation>BBT передачи (такт.доля.тики)</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2500"/>
        <source>Patchbay reset.</source>
        <translation>Коммутатор сброшен.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2512"/>
        <source>Patchbay activated.</source>
        <translation>Коммутатор активирован.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2520"/>
        <source>Patchbay deactivated.</source>
        <translation>Коммутатор деактивирован.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2768"/>
        <source>JACK connection graph change.</source>
        <translation>Смена графа соединений JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2798"/>
        <source>XRUN callback (%1).</source>
        <translation>Обратный вызов XRUN (%1).</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2808"/>
        <source>Buffer size change (%1).</source>
        <translation>Смена размера буфера (%1).</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2831"/>
        <source>Freewheel started...</source>
        <translation>Запущен свободный ход…</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2832"/>
        <source>Freewheel exited.</source>
        <translation>Выход из режима свободного хода.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2845"/>
        <source>Could not start JACK.

Sorry.</source>
        <translation>Не удалось запустить JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2852"/>
        <source>JACK has crashed.</source>
        <translation>Произошёл сбой в работе JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2855"/>
        <source>JACK timed out.</source>
        <translation>Превышено время ожидания запуска JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2858"/>
        <source>JACK write error.</source>
        <translation>Ошибка записи JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2861"/>
        <source>JACK read error.</source>
        <translation>Ошибка чтения JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2865"/>
        <source>Unknown JACK error (%d).</source>
        <translation>Неизвестная ошибка JACK (%d).</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2877"/>
        <source>JACK property change.</source>
        <translation>Изменение свойства JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2899"/>
        <source>ALSA connection graph change.</source>
        <translation>Смена графа соединений ALSA.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2937"/>
        <source>JACK active patchbay scan</source>
        <translation>Сканирование активного коммутатора  JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2947"/>
        <source>ALSA active patchbay scan</source>
        <translation>Сканирование активного коммутатора  ALSA.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="2991"/>
        <source>JACK connection change.</source>
        <translation>Смена соединений JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3000"/>
        <source>ALSA connection change.</source>
        <translation>Смена соединений ALSA.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3091"/>
        <source>A patchbay definition is currently active,
which is probable to redo this connection:

%1 -&gt; %2

Do you want to remove the patchbay connection?</source>
        <translation>В настоящее время активно определение коммутатора,
что может привести к повторному соединению:

%1 -&gt; %2

Удалить соединение коммутатора?</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3809"/>
        <source>%1 (%2%, %3 xruns)</source>
        <translation>%1 (%2%, %3 xrun)</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3837"/>
        <source>FW</source>
        <translation>Свободный ход</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4210"/>
        <source>&amp;Versioning</source>
        <translation>&amp;Версии</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4217"/>
        <source>Re&amp;fresh</source>
        <translation>О&amp;бновить</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4886"/>
        <source>D-BUS: GetParameterConstraint(&apos;%1&apos;):

%2.
(%3)</source>
        <translation>D-BUS: GetParameterConstraint(&apos;%1&apos;):

%2.
(%3)</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="523"/>
        <location filename="../qjackctlMainForm.cpp" line="4235"/>
        <source>&amp;Graph</source>
        <translation>&amp;Граф</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4587"/>
        <source>D-BUS: SetParameterValue(&apos;%1&apos;, &apos;%2&apos;):

%3.
(%4)</source>
        <translation>D-BUS: SetParameterValue(&apos;%1&apos;, &apos;%2&apos;):

%3.
(%4)</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4620"/>
        <source>D-BUS: ResetParameterValue(&apos;%1&apos;):

%2.
(%3)</source>
        <translation>D-BUS: ResetParameterValue(&apos;%1&apos;):

%2.
(%3)</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4862"/>
        <source>D-BUS: GetParameterValue(&apos;%1&apos;):

%2.
(%3)</source>
        <translation>D-BUS: GetParameterValue(&apos;%1&apos;):

%2.
(%3)</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3182"/>
        <source>Overall operation failed.</source>
        <translation>Выполнение операции в целом неудачно.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="1012"/>
        <source>%1 is about to terminate.

Are you sure?</source>
        <translation>%1 сейчас прекратит работу.

Вы уверены?</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3184"/>
        <source>Invalid or unsupported option.</source>
        <translation>Некорректный или неподдерживаемый параметр</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3186"/>
        <source>Client name not unique.</source>
        <translation>Имя клиента не уникально.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3188"/>
        <source>Server is started.</source>
        <translation>Сервер запущен.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3190"/>
        <source>Unable to connect to server.</source>
        <translation>Не удалось соединиться с сервером.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3192"/>
        <source>Server communication error.</source>
        <translation>Ошибка коммуникации с сервером.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3194"/>
        <source>Client does not exist.</source>
        <translation>Клиент не существует.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3196"/>
        <source>Unable to load internal client.</source>
        <translation>Не удалось загрузить внутренний клиент.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3198"/>
        <source>Unable to initialize client.</source>
        <translation>Не удалось инициализировать клиент.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3200"/>
        <source>Unable to access shared memory.</source>
        <translation>Не удалось получить доступ к разделяемой памяти.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3202"/>
        <source>Client protocol version mismatch.</source>
        <translation>Несовпадение версии клиентского протокола.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3204"/>
        <source>Could not connect to JACK server as client.
- %1
Please check the messages window for more info.</source>
        <translation>Не удалось соединиться с сервером JACK.
— %1
Просмотрите вывод в окне сообщений.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3288"/>
        <source>Server configuration saved to &quot;%1&quot;.</source>
        <translation>Конфигурация сервера сохранена в «%1».</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3656"/>
        <source>Transport rewind.</source>
        <translation>Перемотка к началу</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3677"/>
        <source>Transport backward.</source>
        <translation>Перемотка назад</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3745"/>
        <source>Transport forward.</source>
        <translation>Перемотка вперёд</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3805"/>
        <source>%1 (%2%)</source>
        <translation>%1 (%2%)</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3817"/>
        <source>%1 %</source>
        <translation>%1%</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3819"/>
        <source>%1 Hz</source>
        <translation>%1Гц</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3821"/>
        <source>%1 frames</source>
        <translation>%1 выб.</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3883"/>
        <source>%1 msec</source>
        <translation>%1 мс</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="3890"/>
        <source>XRUN callback (%1 skipped).</source>
        <translation>Обратный вызов XRUN (%1 пропущен).</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4124"/>
        <source>Mi&amp;nimize</source>
        <translation>&amp;Свернуть</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4125"/>
        <source>Rest&amp;ore</source>
        <translation>&amp;Восстановить</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4144"/>
        <source>&amp;Reset</source>
        <translation>С&amp;бросить</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4150"/>
        <source>&amp;Presets</source>
        <translation>&amp;Профили</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="421"/>
        <location filename="../qjackctlMainForm.cpp" line="4178"/>
        <source>S&amp;ession</source>
        <translation>С&amp;еансы</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4187"/>
        <source>&amp;Load...</source>
        <translation>&amp;Загрузить...</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4195"/>
        <source>&amp;Save...</source>
        <translation>&amp;Сохранить…</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4200"/>
        <source>Save and &amp;Quit...</source>
        <translation>Сохранить и вы&amp;йти…</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4204"/>
        <source>Save &amp;Template...</source>
        <translation>Сохранить &amp;шаблон…</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.cpp" line="4248"/>
        <source>&amp;Transport</source>
        <translation>&amp;Передача</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="625"/>
        <location filename="../qjackctlMainForm.cpp" line="4250"/>
        <source>&amp;Rewind</source>
        <translation>К &amp;началу</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="489"/>
        <location filename="../qjackctlMainForm.cpp" line="599"/>
        <location filename="../qjackctlMainForm.cpp" line="4267"/>
        <source>Set&amp;up...</source>
        <translation>&amp;Параметры</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="591"/>
        <source>&amp;Patchbay</source>
        <translation>&amp;Коммутатор</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="557"/>
        <source>&amp;Connect</source>
        <translation>&amp;Соединения</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="196"/>
        <source>DSP Load</source>
        <translation>Загрузка DSP</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="244"/>
        <source>XRUN Count (notifications)</source>
        <translation>Число XRUN (уведомлений)</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="418"/>
        <source>Show/hide the session management window</source>
        <translation>Показать/скрыть окно управления сеансами</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="452"/>
        <source>Show/hide the messages log/status window</source>
        <translation>Показать скрыть окно журнала сообщений/состояния</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="520"/>
        <source>Show/hide the graph window</source>
        <translation>Показать/скрыть окно графа</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="554"/>
        <source>Show/hide the connections window</source>
        <translation>Показать/скрыть окно соединений</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="650"/>
        <source>Backward transport</source>
        <translation>Перемотать назад</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="653"/>
        <source>&amp;Backward</source>
        <translation>Н&amp;азад</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="740"/>
        <source>Forward transport</source>
        <translation>Перемотать вперёд</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="743"/>
        <source>&amp;Forward</source>
        <translation>&amp;Вперёд</translation>
    </message>
    <message>
        <location filename="../qjackctlMainForm.ui" line="622"/>
        <source>Rewind transport</source>
        <translation>Перемотать к началу</translation>
    </message>
</context>
<context>
    <name>qjackctlMessagesStatusForm</name>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="39"/>
        <source>Messages / Status</source>
        <translation>Сообщения/статус</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="55"/>
        <source>&amp;Messages</source>
        <translation>С&amp;ообщения</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="58"/>
        <source>Messages log</source>
        <translation>Журнал сообщений</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="70"/>
        <source>Messages output log</source>
        <translation>Журнал выведенных сообщений</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="90"/>
        <source>&amp;Status</source>
        <translation>С&amp;татус</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="93"/>
        <source>Status information</source>
        <translation>Информация о статусе</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="111"/>
        <source>Statistics since last server startup</source>
        <translation>Статистика с последнего запуска сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="133"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="138"/>
        <source>Value</source>
        <translation>Значение</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="146"/>
        <source>Reset XRUN statistic values</source>
        <translation>Обнулить статистику по рассинхронизации</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="149"/>
        <source>Re&amp;set</source>
        <translation>С&amp;бросить</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="175"/>
        <source>Refresh XRUN statistic values</source>
        <translation>Обновить статистику по рассинхронизации</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.ui" line="178"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Обновить</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="86"/>
        <source>Server name</source>
        <translation>Имя сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="88"/>
        <source>Server state</source>
        <translation>Статус сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="90"/>
        <source>DSP Load</source>
        <translation>Загрузка DSP</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="92"/>
        <source>Sample Rate</source>
        <translation>Частота сэмплирования</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="94"/>
        <source>Buffer Size</source>
        <translation>Размер буфера</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="96"/>
        <source>Realtime Mode</source>
        <translation>Режим реального времени</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="99"/>
        <source>Transport state</source>
        <translation>Состояние передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="102"/>
        <source>Transport Timecode</source>
        <translation>Тайм-код передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="104"/>
        <source>Transport BBT</source>
        <translation>BBT передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="106"/>
        <source>Transport BPM</source>
        <translation>BPM передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="109"/>
        <source>XRUN count since last server startup</source>
        <translation>Рассинхронизаций с последнего запуска сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="112"/>
        <source>XRUN last time detected</source>
        <translation>Последняя обнаруженная рассинхронизация</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="114"/>
        <source>XRUN last</source>
        <translation>Последняя рассинхронизация</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="116"/>
        <source>XRUN maximum</source>
        <translation>Максимальная рассинхронизация</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="118"/>
        <source>XRUN minimum</source>
        <translation>Минимальная рассинхронизация</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="120"/>
        <source>XRUN average</source>
        <translation>Средняя длительность рассинхронизаций</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="122"/>
        <source>XRUN total</source>
        <translation>Всего рассинхронизаций</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="126"/>
        <source>Maximum scheduling delay</source>
        <translation>Максимальная задержка расписания</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="129"/>
        <source>Time of last reset</source>
        <translation>Время последнего сброса</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="221"/>
        <source>Logging stopped --- %1 ---</source>
        <translation>Журналирование остановлено --- %1 ---</translation>
    </message>
    <message>
        <location filename="../qjackctlMessagesStatusForm.cpp" line="231"/>
        <source>Logging started --- %1 ---</source>
        <translation>Журналирование запущено --- %1 ---</translation>
    </message>
</context>
<context>
    <name>qjackctlPaletteForm</name>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="40"/>
        <source>Color Themes</source>
        <translation>Цветовые темы</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="46"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="64"/>
        <source>Current color palette name</source>
        <translation>Название текущей цветовой палитры</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="77"/>
        <source>Save current color palette name</source>
        <translation>Сохранить название текущей цветовой палитры</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="80"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="90"/>
        <source>Delete current color palette name</source>
        <translation>Удалить название текущей цветовой палитры</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="93"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="106"/>
        <source>Palette</source>
        <translation>Палитра</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="118"/>
        <source>Current color palette</source>
        <translation>Текущая цветовая палитра</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="128"/>
        <source>Generate:</source>
        <translation>Создать:</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="144"/>
        <source>Base color to generate palette</source>
        <translation>Базовый цвет для генерирования палитры</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="151"/>
        <source>Reset all current palette colors</source>
        <translation>Сбросить все используемые цвета</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="154"/>
        <source> Reset</source>
        <translation> Сбросить</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="177"/>
        <source>Import a custom color theme (palette) from file</source>
        <translation>Импорт пользовательской цветовой темы (палитры) из файла</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="180"/>
        <source>Import...</source>
        <translation>Импорт...</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="190"/>
        <source>Export a custom color theme (palette) to file</source>
        <translation>Экспорт пользовательской цветовой темы (палитры) из файла</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="193"/>
        <source>Export...</source>
        <translation>Экспорт...</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.ui" line="216"/>
        <source>Show Details</source>
        <translation>Подробности</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="344"/>
        <source>Import File - %1</source>
        <translation>Импорт файла — %1</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="260"/>
        <location filename="../qjackctlPaletteForm.cpp" line="347"/>
        <location filename="../qjackctlPaletteForm.cpp" line="392"/>
        <source>Palette files (*.%1)</source>
        <translation>Файлы палитр (*.%1)</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="258"/>
        <source>Save Palette - %1</source>
        <translation>Сохранить палитру — %1</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="261"/>
        <location filename="../qjackctlPaletteForm.cpp" line="348"/>
        <location filename="../qjackctlPaletteForm.cpp" line="393"/>
        <source>All files (*.*)</source>
        <translation>Все файлы (*.*)</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="379"/>
        <location filename="../qjackctlPaletteForm.cpp" line="755"/>
        <location filename="../qjackctlPaletteForm.cpp" line="763"/>
        <source>Warning - %1</source>
        <translation>Предупреждение — %1</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="380"/>
        <source>Could not import from file:

%1

Sorry.</source>
        <translation>Не удалось импортировать из файла:

%1</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="389"/>
        <source>Export File - %1</source>
        <translation>Экспорт файла — %1</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="756"/>
        <source>Some settings have been changed.

Do you want to discard the changes?</source>
        <translation>Некоторые параметры изменились.

Отменить изменения?</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="764"/>
        <source>Some settings have been changed:

&quot;%1&quot;.

Do you want to save the changes?</source>
        <translation>Некоторые параметры изменились:

«%1»

Сохранить изменения?</translation>
    </message>
</context>
<context>
    <name>qjackctlPaletteForm::PaletteModel</name>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="1007"/>
        <source>Color Role</source>
        <translation>Роль цвета</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="1010"/>
        <source>Active</source>
        <translation>Активен</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="1013"/>
        <source>Inactive</source>
        <translation>Не активен</translation>
    </message>
    <message>
        <location filename="../qjackctlPaletteForm.cpp" line="1016"/>
        <source>Disabled</source>
        <translation>Выключен</translation>
    </message>
</context>
<context>
    <name>qjackctlPatchbay</name>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1706"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1707"/>
        <source>This will disconnect all sockets.

Are you sure?</source>
        <translation>Все сокеты будут рассоединены.

Продолжить?</translation>
    </message>
</context>
<context>
    <name>qjackctlPatchbayForm</name>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="432"/>
        <source>&amp;New</source>
        <translation>&amp;Создать</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="429"/>
        <source>Create a new patchbay profile</source>
        <translation>Создать новый профиль коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="448"/>
        <source>&amp;Load...</source>
        <translation>&amp;Загрузить...</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="445"/>
        <source>Load patchbay profile</source>
        <translation>Загрузить профиль коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="464"/>
        <source>&amp;Save...</source>
        <translation>&amp;Сохранить...</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="461"/>
        <source>Save current patchbay profile</source>
        <translation>Сохранить текущий профиль коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="501"/>
        <source>Acti&amp;vate</source>
        <translation>&amp;Активировать</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="322"/>
        <source>&amp;Connect</source>
        <translation>&amp;Соединить</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="319"/>
        <source>Connect currently selected sockets</source>
        <translation>Соединить выбранные сейчас сокеты</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="335"/>
        <source>&amp;Disconnect</source>
        <translation>&amp;Рассоединить</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="332"/>
        <source>Disconnect currently selected sockets</source>
        <translation>Рассоединить выбранные сейчас сокеты</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="348"/>
        <source>Disconnect &amp;All</source>
        <translation>Рассоединить &amp;все</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="345"/>
        <source>Disconnect all currently connected sockets</source>
        <translation>Рассоединить все соединённые сейчас сокеты</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="406"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Обновить</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="403"/>
        <source>Refresh current patchbay view</source>
        <translation>Обновить текущий вид коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="108"/>
        <location filename="../qjackctlPatchbayForm.ui" line="218"/>
        <source>Down</source>
        <translation>Вниз</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="105"/>
        <location filename="../qjackctlPatchbayForm.ui" line="215"/>
        <source>Move currently selected output socket down one position</source>
        <translation>Переместить выбранный сейчас сокет вниз на одну позицию</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="121"/>
        <location filename="../qjackctlPatchbayForm.ui" line="257"/>
        <source>Add...</source>
        <translation>Добавить...</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="118"/>
        <source>Create a new output socket</source>
        <translation>Создать новый сокет выхода</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="150"/>
        <location filename="../qjackctlPatchbayForm.ui" line="270"/>
        <source>Edit...</source>
        <translation>Изменить...</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="147"/>
        <source>Edit currently selected input socket properties</source>
        <translation>Изменить свойства выбранного сейчас сокета входа</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="179"/>
        <location filename="../qjackctlPatchbayForm.ui" line="283"/>
        <source>Up</source>
        <translation>Вверх</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="176"/>
        <location filename="../qjackctlPatchbayForm.ui" line="280"/>
        <source>Move currently selected output socket up one position</source>
        <translation>Переместить выбранный сейчас сокет вверх на одну позицию</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="192"/>
        <location filename="../qjackctlPatchbayForm.ui" line="231"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="189"/>
        <source>Remove currently selected output socket</source>
        <translation>Удалить выбранный сейчас сокет выхода</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="44"/>
        <source>Patchbay</source>
        <translation>Коммутатор</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="228"/>
        <source>Remove currently selected input socket</source>
        <translation>Удалить выбранный сейчас сокет входа</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="254"/>
        <source>Create a new input socket</source>
        <translation>Создать новый сокет входа</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="267"/>
        <source>Edit currently selected output socket properties</source>
        <translation>Изменить свойства выбранного сейчас сокета выхода</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="226"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="610"/>
        <source>active</source>
        <translation>активно</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="451"/>
        <source>New Patchbay definition</source>
        <translation>Новое описание коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="485"/>
        <location filename="../qjackctlPatchbayForm.cpp" line="505"/>
        <source>Patchbay Definition files</source>
        <translation>Файлы описания коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="483"/>
        <source>Load Patchbay Definition</source>
        <translation>Загрузить описание коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="503"/>
        <source>Save Patchbay Definition</source>
        <translation>Сохранить описание коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="227"/>
        <source>The patchbay definition has been changed:

&quot;%1&quot;

Do you want to save the changes?</source>
        <translation>Описание коммутатора изменилось:

«%1»

Сохранить изменения?</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="283"/>
        <source>%1 [modified]</source>
        <translation>%1 [изменено]</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="356"/>
        <source>Untitled%1</source>
        <translation>Без имени %1</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="375"/>
        <location filename="../qjackctlPatchbayForm.cpp" line="405"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="376"/>
        <source>Could not load patchbay definition file: 

&quot;%1&quot;</source>
        <translation>Не удалось загрузить файл описания коммутатора: 

«%1»</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="406"/>
        <source>Could not save patchbay definition file: 

&quot;%1&quot;</source>
        <translation>Не удалось сохранить файл описания коммутатора: 

«%1»</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.cpp" line="452"/>
        <source>Create patchbay definition as a snapshot
of all actual client connections?</source>
        <translation>Создать описание коммутатора как
снимок активных соединений клиентов?</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="202"/>
        <source>Duplicate (copy) currently selected output socket</source>
        <translation>Дублировать (копировать) выбранное в данный момент выходное гнездо</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="205"/>
        <location filename="../qjackctlPatchbayForm.ui" line="244"/>
        <source>Copy...</source>
        <translation>Скопировать...</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="241"/>
        <source>Duplicate (copy) currently selected input socket</source>
        <translation>Дублировать (копировать) выбранное в данный момент входное гнездо</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="374"/>
        <source>Expand all items</source>
        <translation>Развернуть все элементы</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="377"/>
        <source>E&amp;xpand All</source>
        <translation>&amp;Развернуть все</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="491"/>
        <source>Current (recent) patchbay profile(s)</source>
        <translation>Текущий (недавний) профиль коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbayForm.ui" line="498"/>
        <source>Toggle activation of current patchbay profile</source>
        <translation>Включить или отключить текущий профиль коммутатора</translation>
    </message>
</context>
<context>
    <name>qjackctlPatchbayView</name>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1243"/>
        <source>Add...</source>
        <translation>Добавить...</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1245"/>
        <source>Edit...</source>
        <translation>Изменить...</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1251"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1314"/>
        <source>Move Up</source>
        <translation>Выше</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1317"/>
        <source>Move Down</source>
        <translation>Ниже</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1324"/>
        <location filename="../qjackctlPatchbay.cpp" line="1341"/>
        <source>&amp;Connect</source>
        <translation>&amp;Соединить</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1324"/>
        <location filename="../qjackctlPatchbay.cpp" line="1342"/>
        <source>Alt+C</source>
        <comment>Connect</comment>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1328"/>
        <location filename="../qjackctlPatchbay.cpp" line="1345"/>
        <source>&amp;Disconnect</source>
        <translation>&amp;Отсоединить</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1328"/>
        <location filename="../qjackctlPatchbay.cpp" line="1346"/>
        <source>Alt+D</source>
        <comment>Disconnect</comment>
        <translation>Alt+D</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1332"/>
        <location filename="../qjackctlPatchbay.cpp" line="1349"/>
        <source>Disconnect &amp;All</source>
        <translation>Отсоединить &amp;все</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1332"/>
        <location filename="../qjackctlPatchbay.cpp" line="1350"/>
        <source>Alt+A</source>
        <comment>Disconnect All</comment>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1337"/>
        <location filename="../qjackctlPatchbay.cpp" line="1354"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Обновить</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1337"/>
        <location filename="../qjackctlPatchbay.cpp" line="1355"/>
        <source>Alt+R</source>
        <comment>Refresh</comment>
        <translation>Alt+R</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1255"/>
        <source>Exclusive</source>
        <translation>Исключительный</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1248"/>
        <source>Copy...</source>
        <translation>Скопировать...</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1261"/>
        <source>Forward</source>
        <translation>Вперёд</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="1300"/>
        <source>(None)</source>
        <translation>(Нет)</translation>
    </message>
</context>
<context>
    <name>qjackctlSessionForm</name>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="34"/>
        <source>Session</source>
        <translation>Сеанс</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="45"/>
        <source>Load session</source>
        <translation>Загрузить сеанс</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="48"/>
        <location filename="../qjackctlSessionForm.cpp" line="806"/>
        <source>&amp;Load...</source>
        <translation>&amp;Загрузить…</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="58"/>
        <source>Recent session</source>
        <translation>Недавние сеансы</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="61"/>
        <location filename="../qjackctlSessionForm.cpp" line="245"/>
        <source>&amp;Recent</source>
        <translation>&amp;Недавние</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="81"/>
        <source>Save session</source>
        <translation>Сохранить сеанс</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="824"/>
        <source>&amp;Versioning</source>
        <translation>&amp;Версии</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="110"/>
        <location filename="../qjackctlSessionForm.cpp" line="830"/>
        <location filename="../qjackctlSessionForm.cpp" line="996"/>
        <source>Re&amp;fresh</source>
        <translation>О&amp;бновить</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="126"/>
        <source>Session clients / connections</source>
        <translation>Клиенты и соединения сеанса</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="161"/>
        <source>Infra-clients / commands</source>
        <translation>Инфра-клиенты и команды</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="177"/>
        <source>Infra-client</source>
        <translation>Инфра-клиент</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="182"/>
        <source>Infra-command</source>
        <translation>Инфра-команда</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="190"/>
        <source>Add infra-client</source>
        <translation>Добавить инфра-клиент</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="193"/>
        <location filename="../qjackctlSessionForm.cpp" line="986"/>
        <source>&amp;Add</source>
        <translation>&amp;Добавить</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="203"/>
        <source>Edit infra-client</source>
        <translation>Изменить инфра-клиент</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="206"/>
        <location filename="../qjackctlSessionForm.cpp" line="989"/>
        <source>&amp;Edit</source>
        <translation>&amp;Изменить</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="216"/>
        <source>Remove infra-client</source>
        <translation>Удалить инфра-клиент</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="219"/>
        <location filename="../qjackctlSessionForm.cpp" line="992"/>
        <source>Re&amp;move</source>
        <translation>&amp;Удалить</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="251"/>
        <location filename="../qjackctlSessionForm.cpp" line="812"/>
        <source>&amp;Save...</source>
        <translation>&amp;Сохранить…</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="107"/>
        <source>Update session</source>
        <translation>Обновить сеанс</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="142"/>
        <source>Client / Ports</source>
        <translation>Клиенты/порты</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="147"/>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="152"/>
        <source>Command</source>
        <translation>Команда</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.ui" line="84"/>
        <location filename="../qjackctlSessionForm.cpp" line="248"/>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="470"/>
        <location filename="../qjackctlSessionForm.cpp" line="486"/>
        <source>Load Session</source>
        <translation>Загрузить сеанс</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="475"/>
        <source>Session directory</source>
        <translation>Каталог сеансов</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="523"/>
        <source>Save Session</source>
        <translation>Сохранить сеанс</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="529"/>
        <source>and Quit</source>
        <translation>и выйти</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="532"/>
        <source>Template</source>
        <translation>Шаблон</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="584"/>
        <source>&amp;Clear</source>
        <translation>О&amp;чистить</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="609"/>
        <location filename="../qjackctlSessionForm.cpp" line="655"/>
        <location filename="../qjackctlSessionForm.cpp" line="662"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="610"/>
        <source>A session could not be found in this folder:

&quot;%1&quot;</source>
        <translation>Не удалось найти сеанс в каталоге

«%1»</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="624"/>
        <source>%1: loading session...</source>
        <translation>%1: загружается сеанс...</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="637"/>
        <source>%1: load session %2.</source>
        <translation>%1: загрузить сеанс %2.</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="656"/>
        <source>A session already exists in this folder:

&quot;%1&quot;

Are you sure to overwrite the existing session?</source>
        <translation>В этой папке уже есть сеанс:

«%1»

Вы уверены, что хотите перезаписать его?</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="663"/>
        <source>This folder already exists and is not empty:

&quot;%1&quot;

Are you sure to overwrite the existing folder?</source>
        <translation>Эта папка уже существует и не пуста:

«%1»

Вы уверены, что хотите перезаписать существующую папку?</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="680"/>
        <source>%1: saving session...</source>
        <translation>%1: сохраняется сеанс...</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="709"/>
        <source>%1: save session %2.</source>
        <translation>%1: сохранить сеанс %2.</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="843"/>
        <source>New Client</source>
        <translation>Новый клиент</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="255"/>
        <location filename="../qjackctlSessionForm.cpp" line="816"/>
        <source>Save and &amp;Quit...</source>
        <translation>Сохранить и вы&amp;йти…</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="258"/>
        <location filename="../qjackctlSessionForm.cpp" line="819"/>
        <source>Save &amp;Template...</source>
        <translation>Сохранить &amp;шаблон…</translation>
    </message>
</context>
<context>
    <name>qjackctlSessionInfraClientItemEditor</name>
    <message>
        <location filename="../qjackctlSessionForm.cpp" line="138"/>
        <source>Infra-command</source>
        <translation>Инфра-команда</translation>
    </message>
</context>
<context>
    <name>qjackctlSessionSaveForm</name>
    <message>
        <location filename="../qjackctlSessionSaveForm.ui" line="36"/>
        <source>Session</source>
        <translation>Сеанс</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionSaveForm.ui" line="45"/>
        <source>&amp;Name:</source>
        <translation>&amp;Имя:</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionSaveForm.ui" line="61"/>
        <source>Session name</source>
        <translation>Имя сеанса</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionSaveForm.ui" line="73"/>
        <source>&amp;Directory:</source>
        <translation>&amp;Каталог:</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionSaveForm.ui" line="109"/>
        <source>Session directory</source>
        <translation>Каталог сеансов</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionSaveForm.ui" line="134"/>
        <source>Browse for session directory</source>
        <translation>Поиск каталога сеансов</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionSaveForm.ui" line="137"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionSaveForm.ui" line="164"/>
        <source>Save session versioning</source>
        <translation>Сохранять версии сеансов</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionSaveForm.ui" line="167"/>
        <source>&amp;Versioning</source>
        <translation>&amp;Версии</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionSaveForm.cpp" line="134"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionSaveForm.cpp" line="135"/>
        <source>Session directory does not exist:

&quot;%1&quot;

Do you want to create it?</source>
        <translation>Каталог сеансов не существует:

«%1»

Создать его?</translation>
    </message>
    <message>
        <location filename="../qjackctlSessionSaveForm.cpp" line="201"/>
        <source>Session Directory</source>
        <translation>Каталог сеансов</translation>
    </message>
</context>
<context>
    <name>qjackctlSetupForm</name>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="53"/>
        <source>Settings</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="843"/>
        <source>jackd</source>
        <translatorcomment>DO NOT TRANSLATE</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="848"/>
        <source>jackdmp</source>
        <translatorcomment>DO NOT TRANSLATE</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="853"/>
        <source>jackstart</source>
        <translatorcomment>DO NOT TRANSLATE</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="198"/>
        <source>dummy</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/54</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="203"/>
        <source>sun</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/54</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="208"/>
        <source>oss</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/54</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="213"/>
        <source>alsa</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/54</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="218"/>
        <source>portaudio</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/54</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="223"/>
        <source>coreaudio</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/54</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="228"/>
        <source>firewire</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/54</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="155"/>
        <source>Parameters</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="451"/>
        <source>22050</source>
        <translation>22050</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="456"/>
        <source>32000</source>
        <translation>32000</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="461"/>
        <source>44100</source>
        <translation>44100</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="466"/>
        <source>48000</source>
        <translation>48000</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="471"/>
        <source>88200</source>
        <translation>88200</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="476"/>
        <source>96000</source>
        <translation>96000</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="444"/>
        <source>Sample rate in frames per second</source>
        <translation>Частота дискретизации выборок в секунду</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4137"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4142"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4147"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4152"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4157"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1084"/>
        <source>Scheduler priority when running realtime</source>
        <translation>Приоритет планировщика в режиме реального времени</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1189"/>
        <source>21333</source>
        <translation>21333</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="537"/>
        <location filename="../qjackctlSetupForm.ui" line="1135"/>
        <source>16</source>
        <translation>16</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="542"/>
        <location filename="../qjackctlSetupForm.ui" line="1140"/>
        <source>32</source>
        <translation>32</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1062"/>
        <source>Priorit&amp;y:</source>
        <translation>П&amp;риоритет:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1159"/>
        <source>&amp;Wait (usec):</source>
        <translation>О&amp;жидание (мс):</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="508"/>
        <source>&amp;Frames/Period:</source>
        <translation>&amp;Выборок в буфере:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="547"/>
        <location filename="../qjackctlSetupForm.ui" line="1145"/>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="552"/>
        <location filename="../qjackctlSetupForm.ui" line="1282"/>
        <source>128</source>
        <translation>128</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="557"/>
        <location filename="../qjackctlSetupForm.ui" line="1287"/>
        <source>256</source>
        <translation>256</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="562"/>
        <location filename="../qjackctlSetupForm.ui" line="1292"/>
        <source>512</source>
        <translation>512</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="567"/>
        <location filename="../qjackctlSetupForm.ui" line="1297"/>
        <source>1024</source>
        <translation>1024</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="572"/>
        <source>2048</source>
        <translation>2048</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="577"/>
        <source>4096</source>
        <translation>4096</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="530"/>
        <source>Frames per period between process() calls</source>
        <translation>Выборок в период между вызовами process()</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="422"/>
        <source>Sample &amp;Rate:</source>
        <translation>&amp;Частота дискр.:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="968"/>
        <source>H/&amp;W Meter</source>
        <translation>Аппаратный &amp;счётчик</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1524"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1529"/>
        <source>Rectangular</source>
        <translation>Прямоугольное</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1534"/>
        <source>Shaped</source>
        <translation>По очертаниям</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1539"/>
        <source>Triangular</source>
        <translation>Треугольное</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1468"/>
        <source>Duplex</source>
        <translation>Дуплекс</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1464"/>
        <source>Provide either audio capture, playback or both</source>
        <translation>Разрешить захват звука, его воспроизведение или всё сразу</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="305"/>
        <location filename="../qjackctlSetupForm.ui" line="1587"/>
        <location filename="../qjackctlSetupForm.ui" line="1650"/>
        <source>hw:0</source>
        <translation>hw:0</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1312"/>
        <source>&amp;Timeout (msec):</source>
        <translation>&amp;Тайм-аут (мс):</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1492"/>
        <source>Dit&amp;her:</source>
        <translation>Подмешивание &amp;шума:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1344"/>
        <source>200</source>
        <translation>200</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1349"/>
        <location filename="../qjackctlSetupForm.ui" line="3343"/>
        <source>500</source>
        <translation>500</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1354"/>
        <location filename="../qjackctlSetupForm.ui" line="3348"/>
        <source>1000</source>
        <translation>1000</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1359"/>
        <source>2000</source>
        <translation>2000</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1364"/>
        <location filename="../qjackctlSetupForm.ui" line="3358"/>
        <source>5000</source>
        <translation>5000</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1334"/>
        <source>Set client timeout limit in milliseconds</source>
        <translation>Установить тайм-аут для клиента в миллисекундах</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="265"/>
        <source>&amp;Interface:</source>
        <translation>&amp;Интерфейс:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1000"/>
        <source>So&amp;ft Mode</source>
        <translation>&amp;Программный режим</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="984"/>
        <source>&amp;Monitor</source>
        <translation>&amp;Контроль</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="981"/>
        <source>Provide output monitor ports</source>
        <translation>Задействовать порты контроля выхода</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="409"/>
        <source>&amp;Realtime</source>
        <translation>Режим &amp;реал. времени</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="406"/>
        <source>Use realtime scheduling</source>
        <translation>Использовать планирование в реал. времени</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="93"/>
        <location filename="../qjackctlSetupForm.ui" line="300"/>
        <location filename="../qjackctlSetupForm.ui" line="902"/>
        <location filename="../qjackctlSetupForm.ui" line="1582"/>
        <location filename="../qjackctlSetupForm.ui" line="1645"/>
        <location filename="../qjackctlSetupForm.ui" line="3093"/>
        <location filename="../qjackctlSetupForm.ui" line="3184"/>
        <location filename="../qjackctlSetupForm.ui" line="4132"/>
        <source>(default)</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/38</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="681"/>
        <source>Whether to give verbose output on messages</source>
        <translation>Подробно ли выводить сообщения</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="710"/>
        <source>Latency:</source>
        <translation>Задержка:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="735"/>
        <source>Output latency in milliseconds, calculated based on the period, rate and buffer settings</source>
        <translation>Задержка выхода в мс, расчитанных на основе настроек периода, частоты и буфера</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2029"/>
        <source>Options</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2041"/>
        <source>Scripting</source>
        <translation>Сценарии</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2065"/>
        <source>Execute script on Start&amp;up:</source>
        <translation>Выполнять сценарий при &amp;запуске:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2062"/>
        <source>Whether to execute a custom shell script before starting up the JACK audio server.</source>
        <translation>Выполнять ли собственный сценарий перед запуском сервера JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2081"/>
        <source>Execute script after &amp;Startup:</source>
        <translation>Выполнять сценарий после з&amp;апуска:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2078"/>
        <source>Whether to execute a custom shell script after starting up the JACK audio server.</source>
        <translation>Выполнять ли собственный сценарий после запуска сервера JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2362"/>
        <source>Whether to execute a custom shell script after shuting down the JACK audio server.</source>
        <translation>Выполнять ли собственный сценарий после остановки сервера JACK.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2116"/>
        <source>Command line to be executed before starting up the JACK audio server</source>
        <translation>Команда, выполняемая перед запуском сервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2181"/>
        <location filename="../qjackctlSetupForm.ui" line="2265"/>
        <location filename="../qjackctlSetupForm.ui" line="2327"/>
        <location filename="../qjackctlSetupForm.ui" line="2427"/>
        <location filename="../qjackctlSetupForm.ui" line="2622"/>
        <location filename="../qjackctlSetupForm.ui" line="2754"/>
        <location filename="../qjackctlSetupForm.ui" line="3135"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2178"/>
        <source>Browse for script to be executed before starting up the JACK audio server</source>
        <translation>Указать сценарий, выполняемый перед запуском сервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2200"/>
        <source>Command line to be executed after starting up the JACK audio server</source>
        <translation>Команда, выполняемая после запуска сервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2262"/>
        <source>Browse for script to be executed after starting up the JACK audio server</source>
        <translation>Указать сценарий, выполняемый после запуска сервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2424"/>
        <source>Browse for script to be executed after shutting down the JACK audio server</source>
        <translation>Указать сценарий, выполняемый после остановки сервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2446"/>
        <source>Command line to be executed after shutting down the JACK audio server</source>
        <translation>Команда, выполняемая после остановки сервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2465"/>
        <source>Statistics</source>
        <translation>Статистика</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2502"/>
        <source>&amp;XRUN detection regex:</source>
        <translation>&amp;Регулярное выражение для определения XRUN:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2534"/>
        <source>xrun of at least ([0-9|\.]+) msecs</source>
        <translation>xrun не менее ([0-9|\.]+) мс</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2527"/>
        <source>Regular expression used to detect XRUNs on server output messages</source>
        <translation>Регулярное выражение для определения рассинхронизаций
среди сообщений от сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2551"/>
        <source>Connections</source>
        <translation>Соединения</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2588"/>
        <source>Patchbay definition file to be activated as connection persistence profile</source>
        <translation>Файл описания коммутатора, активируемый как профиль постоянного соединения</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2619"/>
        <source>Browse for a patchbay definition file to be activated</source>
        <translation>Указать активируемый файл описания коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2569"/>
        <source>Activate &amp;Patchbay persistence:</source>
        <translation>Активировать &amp;постоянный коммутатор:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2566"/>
        <source>Whether to activate a patchbay definition for connection persistence profile.</source>
        <translation>Активировать ли описание коммутатора для профиля постоянного соединения.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2765"/>
        <source>Display</source>
        <translation>Интерфейс</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2813"/>
        <source>Transport &amp;BBT (bar:beat.ticks)</source>
        <translation>&amp;BBT передачи (такт:доля.тики)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2826"/>
        <source>Elapsed time since last &amp;Reset</source>
        <translation>Время, прошедшее с последнего &amp;сброса</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2839"/>
        <source>Elapsed time since last &amp;XRUN</source>
        <translation>Время, пошедшее с последней &amp;рассинхронизации</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3214"/>
        <source>Messages Window</source>
        <translation>Окно сообщений</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3247"/>
        <source>Sample messages text font display</source>
        <translation>Каким будет шрифт для вывода сообщений сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2974"/>
        <location filename="../qjackctlSetupForm.ui" line="2993"/>
        <location filename="../qjackctlSetupForm.ui" line="3278"/>
        <location filename="../qjackctlSetupForm.ui" line="3446"/>
        <source>&amp;Font...</source>
        <translation>&amp;Шрифт...</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3275"/>
        <source>Select font for the messages text display</source>
        <translation>Выберите шрифт для отображения сообщений сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1100"/>
        <source>msec</source>
        <translation>мс</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1102"/>
        <source>n/a</source>
        <translation>н/д</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1565"/>
        <source>Patchbay Definition files</source>
        <translation>Файлы описания коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="169"/>
        <source>Driv&amp;er:</source>
        <translation>&amp;Драйвер:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="67"/>
        <source>Preset &amp;Name:</source>
        <translation>Имя &amp;профиля:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="86"/>
        <source>Settings preset name</source>
        <translation>Имя профиля параметров</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="120"/>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="117"/>
        <source>Save settings as current preset name</source>
        <translation>Сохранить параметры в текущий профиль</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="136"/>
        <source>&amp;Delete</source>
        <translation>&amp;Удалить</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="133"/>
        <source>Delete current settings preset</source>
        <translation>Удалить текущий профиль</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1436"/>
        <source>&amp;Audio:</source>
        <translation>&amp;Звук:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1016"/>
        <source>Force &amp;16bit</source>
        <translation>Принудительно &amp;16 бит</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1013"/>
        <source>Force 16bit mode instead of failing over 32bit (default)</source>
        <translation>Принудительно использовать 16-битный режим вместо 32-битного (по умолчанию)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="591"/>
        <source>Periods/&amp;Buffer:</source>
        <translation>Периодов на &amp;буфер:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2006"/>
        <source>Time in seconds that client is delayed after server startup</source>
        <translation>Сколько секунд клиент ждёт после запуска сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2150"/>
        <location filename="../qjackctlSetupForm.ui" line="2234"/>
        <location filename="../qjackctlSetupForm.ui" line="2296"/>
        <location filename="../qjackctlSetupForm.ui" line="2396"/>
        <source>&gt;</source>
        <translation>&gt;</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2147"/>
        <location filename="../qjackctlSetupForm.ui" line="2231"/>
        <location filename="../qjackctlSetupForm.ui" line="2293"/>
        <location filename="../qjackctlSetupForm.ui" line="2393"/>
        <source>Scripting argument meta-symbols</source>
        <translation>Метасимволы аргументов в сценариях</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2489"/>
        <source>&amp;Capture standard output</source>
        <translation>&amp;Захватывать стандартный вывод</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2486"/>
        <source>Whether to capture standard output (stdout/stderr) into messages window</source>
        <translation>Захватывать ли стандартный вывод (stdout/stderr)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3664"/>
        <source>Other</source>
        <translation>Другое</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3712"/>
        <source>&amp;Confirm application close</source>
        <translation>За&amp;прашивать подтверждение на выход</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3709"/>
        <source>Whether to ask for confirmation on application exit</source>
        <translation>Спрашивать ли подтверждение на выход из программы</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1438"/>
        <source>&amp;Preset Name</source>
        <translation>Имя &amp;профиля</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1441"/>
        <source>&amp;Server Path</source>
        <translation>За&amp;пуск сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1442"/>
        <source>&amp;Driver</source>
        <translation>&amp;Драйвер</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1443"/>
        <source>&amp;Interface</source>
        <translation>&amp;Интерфейс</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1445"/>
        <source>Sample &amp;Rate</source>
        <translation>&amp;Частота дискр.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1446"/>
        <source>&amp;Frames/Period</source>
        <translation>&amp;Выборок/период</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1447"/>
        <source>Periods/&amp;Buffer</source>
        <translation>Периодов/&amp;буфер</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1244"/>
        <source>Port Ma&amp;ximum:</source>
        <translation>&amp;Макс. портов:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1272"/>
        <source>Maximum number of ports the JACK server can manage</source>
        <translation>Максимальное кол-во портов, обрабатываемых сервером JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1616"/>
        <source>&amp;Input Device:</source>
        <translation>Устройство &amp;входа:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1553"/>
        <source>&amp;Output Device:</source>
        <translation>Устройство в&amp;ыхода:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="320"/>
        <location filename="../qjackctlSetupForm.ui" line="1602"/>
        <location filename="../qjackctlSetupForm.ui" line="1665"/>
        <source>/dev/dsp</source>
        <translation>/dev/dsp</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="936"/>
        <source>No Memory Loc&amp;k</source>
        <translation>Б&amp;ез блокировки памяти</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="933"/>
        <source>Do not attempt to lock memory, even if in realtime mode</source>
        <translation>Не пытайтесь заблокировать память, даже в режиме реального времени</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1032"/>
        <source>&amp;Ignore H/W</source>
        <translation>&amp;Игнорировать апп. буфер и период</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1106"/>
        <source>&amp;Word Length:</source>
        <translation>Ра&amp;зрядность слова:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2777"/>
        <source>Time Display</source>
        <translation>Отображение времени</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2800"/>
        <source>Transport &amp;Time Code</source>
        <translation>&amp;Тайм-код передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2887"/>
        <source>Sample front panel normal display font</source>
        <translation>Пример текста в малом счётчике</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2927"/>
        <source>Sample big time display font</source>
        <translation>Пример текста в большом счётчике</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3009"/>
        <source>Normal display:</source>
        <translation>Малый счётчик:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2955"/>
        <source>Big Time display:</source>
        <translation>Большой счётчик:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3310"/>
        <source>&amp;Messages limit:</source>
        <translation>Предел кол-ва &amp;сообщений:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3307"/>
        <source>Whether to keep a maximum number of lines in the messages window</source>
        <translation>Ограничивать ли количество строк в окне сообщений</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3333"/>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3338"/>
        <source>250</source>
        <translation>250</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3353"/>
        <source>2500</source>
        <translation>2500</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3323"/>
        <source>The maximum number of message lines to keep in view</source>
        <translation>Максимальное количество строк сообщений, доступное при просмотре</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3696"/>
        <source>&amp;Start JACK audio server on application startup</source>
        <translation>&amp;Запускать звуковой сервер JACK при старте программы</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3693"/>
        <source>Whether to start JACK audio server immediately on application startup</source>
        <translation>Запускать ли сервер JACK при старте QJackCtl</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3745"/>
        <source>&amp;Keep child windows always on top</source>
        <translation>О&amp;кна программы всегда наверху</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3742"/>
        <source>Whether to keep all child windows on top of the main window</source>
        <translation>Определяет, держать ли все дочерние окна поверх главного окна</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3761"/>
        <source>&amp;Enable system tray icon</source>
        <translation>&amp;Включить область уведомления</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3758"/>
        <source>Whether to enable the system tray icon</source>
        <translation>Включать ли область уведомления
(системный лоток, system tray)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3819"/>
        <source>S&amp;ave JACK audio server configuration to:</source>
        <translation>Со&amp;хранять конфигурацию JACK в файл:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3816"/>
        <source>Whether to save the JACK server command-line configuration into a local file (auto-start)</source>
        <translation>Определяет, сохранять ли конфигурацию командной строки сервера JACK в локальный файл (автозапуск)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3839"/>
        <source>.jackdrc</source>
        <translation>.jackdrc</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3832"/>
        <source>The server configuration local file name (auto-start)</source>
        <translation>Имя локального файла конфигурации сервера (автозапуск)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="94"/>
        <source>System</source>
        <translation>Система</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="95"/>
        <source>Cycle</source>
        <translation>Цикл</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="96"/>
        <source>HPET</source>
        <translation>HPET</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="101"/>
        <source>Don&apos;t restrict self connect requests (default)</source>
        <translation>Не ограничивать запросы на самосоединение (по умолчанию)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="104"/>
        <source>Fail self connect requests to external ports only</source>
        <translation>Отклонять запросы на самосоединение только с внешними портами</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="107"/>
        <source>Ignore self connect requests to external ports only</source>
        <translation>Игнорировать запросы на самосоединение только с внешними портами</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="110"/>
        <source>Fail all self connect requests</source>
        <translation>Отклонять все запросы на самосоединение</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="113"/>
        <source>Ignore all self connect requests</source>
        <translation>Игнорировать все запросы на самосоединение</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1003"/>
        <location filename="../qjackctlSetupForm.cpp" line="1066"/>
        <location filename="../qjackctlSetupForm.cpp" line="2148"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1004"/>
        <source>Some settings have been changed:

&quot;%1&quot;

Do you want to save the changes?</source>
        <translation>Некоторые параметры изменились:

«%1»

Сохранить изменения?</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1067"/>
        <source>Delete preset:

&quot;%1&quot;

Are you sure?</source>
        <translation>Удалить профиль:

«%1»

Вы уверены?</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1440"/>
        <source>&amp;Server Name</source>
        <translation>&amp;Имя сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1495"/>
        <source>Startup Script</source>
        <translation>Сценарий, выполняемый при запуске</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1512"/>
        <source>Post-Startup Script</source>
        <translation>Сценарий, выполняемый после запуска</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1529"/>
        <source>Shutdown Script</source>
        <translation>Сценарий, выполняемый при выключении</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1546"/>
        <source>Post-Shutdown Script</source>
        <translation>Сценарий, выполняемый после выключения</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1563"/>
        <source>Active Patchbay Definition</source>
        <translation>Активное описание коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1581"/>
        <source>Messages Log</source>
        <translation>Журнал сообщений</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1583"/>
        <source>Log files</source>
        <translation>Файлы журналов</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1982"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="1983"/>
        <source>Some settings may be only effective
next time you start this application.</source>
        <translation>Некоторые параметры вступят в силу
только при следующем запуске приложения.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.cpp" line="2149"/>
        <source>Some settings have been changed.

Do you want to apply the changes?</source>
        <translation>Некоторые параметры были изменены.

Применить эти изменения?</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="867"/>
        <source>&amp;Name:</source>
        <translation>&amp;Название:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="895"/>
        <source>The JACK Audio Connection Kit sound server name</source>
        <translation>Имя звукового сервера  JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="191"/>
        <source>The audio backend driver interface to use</source>
        <translation>Используемый звуковой драйвер</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="347"/>
        <source>MIDI Driv&amp;er:</source>
        <translation>&amp;Драйвер MIDI:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="375"/>
        <source>The ALSA MIDI backend driver to use</source>
        <translation>Используемый драйвер ALSA MIDI</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="382"/>
        <source>none</source>
        <translation>нет</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="387"/>
        <source>raw</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/54</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="392"/>
        <source>seq</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/54</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="781"/>
        <source>Please do not touch these settings unless you know what you are doing.</source>
        <translation>Меняйте эти параметры только если точно знаете, что делаете.</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="949"/>
        <source>Unlock memory of common toolkit libraries (GTK+, QT, FLTK, Wine)</source>
        <translation>Разблокировать память основных библиотек интерфейсов (GTK+, QT, FLTK, Wine)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="952"/>
        <source>&amp;Unlock Memory</source>
        <translation>&amp;Разблокировать память</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="997"/>
        <source>Ignore xruns reported by the backend driver</source>
        <translation>Игнорировать xrun, о которых сообщает драйвер</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="965"/>
        <source>Enable hardware metering on cards that support it</source>
        <translation>Включить аппаратное измерение для поддерживающих эту функцию карт</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1029"/>
        <source>Ignore hardware period/buffer size</source>
        <translation>Игнорировать аппаратный размер периода/буфера</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="684"/>
        <source>&amp;Verbose messages</source>
        <translation>&amp;Подробный вывод</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1713"/>
        <source>Maximum input audio hardware channels to allocate</source>
        <translation>Максимальное число резервируемых каналов входа</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1819"/>
        <source>External output latency (frames)</source>
        <translation>Задержка внешнего выхода (в выборках)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1473"/>
        <source>Capture Only</source>
        <translation>Только захват</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1478"/>
        <source>Playback Only</source>
        <translation>Только воспроизведение</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="293"/>
        <source>The PCM device name to use</source>
        <translation>Имя используемого устройства PCM</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="310"/>
        <location filename="../qjackctlSetupForm.ui" line="1592"/>
        <location filename="../qjackctlSetupForm.ui" line="1655"/>
        <source>plughw:0</source>
        <translation>plughw:0</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="315"/>
        <location filename="../qjackctlSetupForm.ui" line="1597"/>
        <location filename="../qjackctlSetupForm.ui" line="1660"/>
        <source>/dev/audio</source>
        <translation>/dev/audio</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1638"/>
        <source>Alternate input device for capture</source>
        <translation>Выберите устройство входа для захвата</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1741"/>
        <source>Maximum output audio hardware channels to allocate</source>
        <translation>Максимальное резервируемое число звуковых каналов устройства</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1575"/>
        <source>Alternate output device for playback</source>
        <translation>Альтернативное устройство воспроизведения</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1791"/>
        <source>External input latency (frames)</source>
        <translation>Задержка внешнего входа (в выборках)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1520"/>
        <source>Set dither mode</source>
        <translation>Выберите способ подмешивания шума</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="836"/>
        <source>Server path (command line prefix)</source>
        <translation>Путь к серверу (префикс командной строки)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="613"/>
        <source>Number of periods in the hardware buffer</source>
        <translation>Количество периодов в аппаратном буфере</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1203"/>
        <source>&amp;Channels:</source>
        <translation>&amp;Каналов:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="481"/>
        <source>192000</source>
        <translation>192000</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1128"/>
        <source>Word length</source>
        <translation>Длина слова в байтах</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1228"/>
        <source>Maximum number of audio channels to allocate</source>
        <translation>Максимальное число резервируемых звуковых каналов</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1679"/>
        <source>&amp;Channels I/O:</source>
        <translation>Ввод/вывод &amp;каналов:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1757"/>
        <source>&amp;Latency I/O:</source>
        <translation>&amp;Задержка ввода/вывода:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1943"/>
        <source>Server Suffi&amp;x:</source>
        <translation>Су&amp;ффикс сервера:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2094"/>
        <source>Whether to execute a custom shell script before shuting down the JACK audio server.</source>
        <translation>Определяет, выполнять ли пользовательский сценарий оболочки перед выключением аудиосервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2097"/>
        <source>Execute script on Shut&amp;down:</source>
        <translation>В&amp;ыполнять сценарий при выходе:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2324"/>
        <source>Browse for script to be executed before shutting down the JACK audio server</source>
        <translation>Выбор сценария, который будет выполняться перед выключением аудиосервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2346"/>
        <source>Command line to be executed before shutting down the JACK audio server</source>
        <translation>Командная строка, которая будет выполняться перед выключением аудиосервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2365"/>
        <source>Execute script after Shu&amp;tdown:</source>
        <translation>Выполнять сценарий после &amp;выключения:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2635"/>
        <source>Whether to reset all connections when a patchbay definition is activated.</source>
        <translation>Определяет, сбрасывать ли все соединения при активации описания коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2638"/>
        <source>&amp;Reset all connections on patchbay activation</source>
        <translation>С&amp;брасывать все соединения при активации коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2651"/>
        <source>Whether to issue a warning on active patchbay port disconnections.</source>
        <translation>Определяет, показывать ли предупреждение о рассоединениии портов активного коммутатора</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2654"/>
        <source>&amp;Warn on active patchbay disconnections</source>
        <translation>Предупре&amp;ждать о рассоединении в активном коммутаторе</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2683"/>
        <source>Logging</source>
        <translation>Журналирование</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2720"/>
        <source>Messages log file</source>
        <translation>Файл журнала сообщений</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2751"/>
        <source>Browse for the messages log file location</source>
        <translation>Указать расположение файла журнала</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2698"/>
        <source>Whether to activate a messages logging to file.</source>
        <translation>Определяет, сохранять ли протокол в файл журнала</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="34"/>
        <source>Setup</source>
        <translation>Настройка</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="650"/>
        <source>Whether to use server synchronous mode</source>
        <translation>Использовать ли синхронный режим сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="653"/>
        <source>&amp;Use server synchronous mode</source>
        <translation>Использовать син&amp;хронный режим сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="760"/>
        <source>Advanced</source>
        <translation>Дополнительные</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2701"/>
        <source>&amp;Messages log file:</source>
        <translation>Файл &amp;журнала:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2971"/>
        <source>Select font for front panel normal display</source>
        <translation>Выбрать шрифт для малого счётчика</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2990"/>
        <source>Select font for big time display</source>
        <translation>Выбрать шрифт для большого счётчика</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3025"/>
        <source>Whether to enable blinking (flashing) of the server mode (RT) indicator</source>
        <translation>Определяет, включать ли мерцание (мигание) индикатора режима сервера (RT)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3028"/>
        <source>Blin&amp;k server mode indicator</source>
        <translation>&amp;Мерцать индикатором режима сервера</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3388"/>
        <source>Connections Window</source>
        <translation>Окно соединений</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3415"/>
        <source>Sample connections view font</source>
        <translation>Шрифт для диалога управления соединениями</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3443"/>
        <source>Select font for the connections view</source>
        <translation>Выберите шрифт для просмотра соединений</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3475"/>
        <source>&amp;Icon size:</source>
        <translation>&amp;Размер значков:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3497"/>
        <source>The icon size for each item of the connections view</source>
        <translation>Размер значка каждого элемента в окне соединений</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3507"/>
        <source>16 x 16</source>
        <translation>16 × 16</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3512"/>
        <source>32 x 32</source>
        <translation>32 × 32</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3517"/>
        <source>64 x 64</source>
        <translation>64 × 64</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3616"/>
        <source>Whether to enable in-place client/port name editing (rename)</source>
        <translation>Определяет, разрешить ли редактирование (переименование) алиасов клиентов/портов</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3619"/>
        <source>Ena&amp;ble client/port aliases editing (rename)</source>
        <translation>Ра&amp;зрешить редактирование (переименование) алиасов клиентов/портов</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3544"/>
        <source>Whether to enable client/port name aliases on the connections window</source>
        <translation>Определяет, включать ли алиасы имён клиентов/портов в окне соединений</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3547"/>
        <source>E&amp;nable client/port aliases</source>
        <translation>&amp;Разрешить алиасы клиентов/портов</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="811"/>
        <source>Server &amp;Prefix:</source>
        <translation>Пре&amp;фикс сервера:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1968"/>
        <source>Extra driver options (command line suffix)</source>
        <translation>Дополнительные ключи драйвера (суффикс в командной строке)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1984"/>
        <source>Start De&amp;lay:</source>
        <translation>Задер&amp;жка запуска:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="2009"/>
        <source> secs</source>
        <translation> с</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="744"/>
        <source>0 msecs</source>
        <translation>0 мс</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3646"/>
        <source>Misc</source>
        <translation>Разное</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3901"/>
        <source>Whether to stop JACK audio server on application exit</source>
        <translation>Останавливать ли звуковой сервер JACK при выходе из приложения</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3904"/>
        <source>S&amp;top JACK audio server on application exit</source>
        <translation>Оста&amp;навливать JACK при выходе из приложения</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3790"/>
        <source>Whether to start minimized to system tray</source>
        <translation>Запускать ли приложение в области уведомления, скрывая основное окно</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="101"/>
        <source>Clear settings of current preset name</source>
        <translation>Очистить параметры текущего профиля</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="104"/>
        <source>Clea&amp;r</source>
        <translation>О&amp;чистить</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1378"/>
        <source>Cloc&amp;k source:</source>
        <translation>Источник данных часо&amp;в:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1400"/>
        <source>Clock source</source>
        <translation>Источник данных часов</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1878"/>
        <source>S&amp;elf connect mode:</source>
        <translation>Режим &amp;самосоединения:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1894"/>
        <source>Whether to restrict client self-connections</source>
        <translation>Определяет, ограничивать ли самосоединение клиентов</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3046"/>
        <source>Custom</source>
        <translation>Пользовательские</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3067"/>
        <source>&amp;Color palette theme:</source>
        <translation>Тема &amp;цветовой палитры:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3086"/>
        <source>Custom color palette theme</source>
        <translation>Пользовательская тема цветовой палитры</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3098"/>
        <source>Wonton Soup</source>
        <translatorcomment>DO NOT TRANSLATE</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3103"/>
        <source>KXStudio</source>
        <translatorcomment>DO NOT TRANSLATE</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3132"/>
        <source>Manage custom color palette themes</source>
        <translation>Управлять пользовательскими темами цветовой палитры</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3161"/>
        <source>&amp;Widget style theme:</source>
        <translation>Тема стиля вид&amp;жетов:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3177"/>
        <source>Custom widget style theme</source>
        <translation>Пользовательская тема стиля виджетов</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3632"/>
        <source>JACK client/port pretty-name (metadata) display mode</source>
        <translation>Режим отображения читабельного имени (метаданных) клиента/порта JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3635"/>
        <source>Enable JA&amp;CK client/port pretty-names (metadata)</source>
        <translation>Включить читабельные имена клиента/порта JA&amp;CK (метаданные)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3725"/>
        <source>Whether to ask for confirmation on JACK audio server shutdown and/or restart</source>
        <translation>Определяет, нужно ли запрашивать подтверждение при выключении и/или перезапуске звукового сервера JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3728"/>
        <source>Confirm server sh&amp;utdown and/or restart</source>
        <translation>Запрашивать по&amp;дтверждение остановки и перезагрузки</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3774"/>
        <source>Whether to show system tray message on main window close</source>
        <translation>Показывать ли сообщения программы в области уведомления, когда основное окно скрыто</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3777"/>
        <source>Sho&amp;w system tray message on close</source>
        <translation>Показывать сооб&amp;щения в области уведомления</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3793"/>
        <source>Start minimi&amp;zed to system tray</source>
        <translation>Запускаться свёрнутым в системный &amp;лоток</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3853"/>
        <source>Whether to enable ALSA Sequencer (MIDI) support on startup</source>
        <translation>Включать ли при запуске поддержку MIDI-секвенсера ALSA</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3856"/>
        <source>E&amp;nable ALSA Sequencer support</source>
        <translation>&amp;Включить поддержку секвенсера ALSA</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3885"/>
        <source>Whether to enable JACK D-Bus interface</source>
        <translation>Включать ли интерфейс JACK по шине D-Bus</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3888"/>
        <source>&amp;Enable JACK D-Bus interface</source>
        <translation>Вкл&amp;ючить интерфейс JACK к шине D-Bus</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3951"/>
        <source>Buttons</source>
        <translation>Кнопки</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3974"/>
        <source>Whether to hide the left button group on the main window</source>
        <translation>Скрывать ли группу кнопок в левой части основного окна</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3977"/>
        <source>Hide main window &amp;Left buttons</source>
        <translation>Скрывать &amp;левые кнопки основного окна</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3990"/>
        <source>Whether to hide the right button group on the main window</source>
        <translation>Скрывать ли группу кнопок в правой части основного окна</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3993"/>
        <source>Hide main window &amp;Right buttons</source>
        <translation>Скрывать прав&amp;ые кнопки основного окна</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4006"/>
        <source>Whether to hide the transport button group on the main window</source>
        <translation>Скрывать ли группу кнопок управления передачей в основном окне</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4009"/>
        <source>Hide main window &amp;Transport buttons</source>
        <translation>Скрывать кнопки &amp;передачи</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4022"/>
        <source>Whether to hide the text labels on the main window buttons</source>
        <translation>Скрывать ли надписи на кнопках в основном окне</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4025"/>
        <source>Hide main window &amp;button text labels</source>
        <translation>Скрывать по&amp;дписи кнопок основного окна</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3560"/>
        <source>&amp;JACK client/port aliases:</source>
        <translation>&amp;Алиасы клиентов/портов JACK:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3582"/>
        <source>JACK client/port aliases display mode</source>
        <translation>Режим отображения алиасов клиентов/портов JACK</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3592"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3597"/>
        <source>First</source>
        <translation>Первый</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3602"/>
        <source>Second</source>
        <translation>Второй</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4051"/>
        <source>Whether to replace Connections with Graph button on the main window</source>
        <translation>Заменить ли кнопку «Соединения» на кнопку «Граф» в главном окне</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4054"/>
        <source>Replace Connections with &amp;Graph button</source>
        <translation>Заменить кнопку «Соединения» на кнопку «&amp;Граф»</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4072"/>
        <source>Defaults</source>
        <translation>Используемые по умолчанию параметры</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4106"/>
        <source>&amp;Base font size:</source>
        <translation>&amp;Кегль шрифта в интерфейсе:</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4125"/>
        <source>Base application font size (pt.)</source>
        <translation>Кегль шрифта приложения (пт.)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4162"/>
        <source>11</source>
        <translation>11</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="4167"/>
        <source>12</source>
        <translation>12</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="233"/>
        <source>net</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/54</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3869"/>
        <source>Whether to enable D-Bus interface</source>
        <translation>Влючать ли интерфейс D-Bus</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3872"/>
        <source>&amp;Enable D-Bus interface</source>
        <translation>Вклю&amp;чить интерфейс D-Bus</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="1182"/>
        <source>Number of microseconds to wait between engine processes (dummy)</source>
        <translation>Время ожидания в микросекундах между этапами обработки (фиктивное)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="238"/>
        <source>netone</source>
        <translatorcomment>DO NOT TRANSLATE - https://github.com/rncbc/qjackctl/issues/54</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3917"/>
        <source>Whether to restrict to one single application instance (X11)</source>
        <translation>Определяет, ограничивать ли до одной копии программы (X11)</translation>
    </message>
    <message>
        <location filename="../qjackctlSetupForm.ui" line="3920"/>
        <source>Single application &amp;instance</source>
        <translation>Зап&amp;ускать только одну копию программы</translation>
    </message>
</context>
<context>
    <name>qjackctlSocketForm</name>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="52"/>
        <source>&amp;Socket</source>
        <translation>&amp;Сокет</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="189"/>
        <source>&amp;Client:</source>
        <translation>&amp;Клиент:</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="80"/>
        <source>Socket name (an alias for client name)</source>
        <translation>Имя сокета (псевдоним имени клиента)</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="64"/>
        <source>&amp;Name (alias):</source>
        <translation>&amp;Имя (псевдоним):</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="155"/>
        <source>Socket Plugs / Ports</source>
        <translation>Сокетовые штепсели/порты</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="139"/>
        <source>Socket plug list</source>
        <translation>Список штепселей сокета</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="208"/>
        <source>&amp;Down</source>
        <translation>В&amp;низ</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="221"/>
        <source>&amp;Up</source>
        <translation>В&amp;верх</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="97"/>
        <source>Add plug to socket plug list</source>
        <translation>Добавить штепсель в список штепселей сокета</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="33"/>
        <source>Socket</source>
        <translation>Сокет</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="110"/>
        <source>&amp;Plug:</source>
        <translation>&amp;Штепсель:</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="166"/>
        <source>&amp;Edit</source>
        <translation>И&amp;зменить</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="179"/>
        <source>&amp;Remove</source>
        <translation>&amp;Удалить</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="176"/>
        <source>Remove currently selected plug from socket plug list</source>
        <translation>Удалить выбранный штепсель из списка штепселей сокета</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.cpp" line="166"/>
        <source>Plugs / Ports</source>
        <translation>Штепсели/порты</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.cpp" line="349"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.cpp" line="350"/>
        <source>A socket named &quot;%1&quot; already exists.</source>
        <translation>Сокет с именем «%1» уже существует.</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.cpp" line="536"/>
        <source>Add Plug</source>
        <translation>Добавить штепсель</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.cpp" line="553"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.cpp" line="550"/>
        <source>Edit</source>
        <translation>Изменить</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.cpp" line="557"/>
        <source>Move Up</source>
        <translation>Переместить выше</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.cpp" line="560"/>
        <source>Move Down</source>
        <translation>Переместить ниже</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="87"/>
        <source>Client name (regular expression)</source>
        <translation>Имя клиента (регулярное выражение)</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="100"/>
        <source>Add P&amp;lug</source>
        <translation>Добавить &amp;штепсель</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="126"/>
        <source>Port name (regular expression)</source>
        <translation>Имя порта (регулярное выражение)</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="283"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="298"/>
        <source>&amp;Audio</source>
        <translation>&amp;Звук</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="295"/>
        <source>Audio socket type (JACK)</source>
        <translation>Тип звукового сокета (JACK)</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="308"/>
        <source>&amp;MIDI</source>
        <translation>&amp;MIDI</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="315"/>
        <source>MIDI socket type (ALSA)</source>
        <translation>Тип MIDI-сокета (ALSA)</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="250"/>
        <source>E&amp;xclusive</source>
        <translation>И&amp;сключительный</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="247"/>
        <source>Enforce only one exclusive cable connection</source>
        <translation>Принудительно только одно кабельное соединение</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.cpp" line="369"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.cpp" line="370"/>
        <source>Some settings have been changed.

Do you want to apply the changes?</source>
        <translation>Некоторые параметры были изменены.

Применить эти изменения?</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.cpp" line="742"/>
        <source>(None)</source>
        <translation>(Нет)</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="163"/>
        <source>Edit currently selected plug</source>
        <translation>Изменить выбранный штепсель</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="205"/>
        <source>Move down currently selected plug in socket plug list</source>
        <translation>Переместить выбранный штепсель вниз в списке штепселей сокета</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="218"/>
        <source>Move up current selected plug in socket plug list</source>
        <translation>Переместить выбранный штепсель вверх в списке штепселей сокета</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="257"/>
        <source>&amp;Forward:</source>
        <translation>&amp;Передача:</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="273"/>
        <source>Forward (clone) all connections from this socket</source>
        <translation>Передача (клонирование) всех соединения от этого сокета</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="305"/>
        <source>MIDI socket type (JACK)</source>
        <translation>Тип MIDI-сокета (JACK)</translation>
    </message>
    <message>
        <location filename="../qjackctlSocketForm.ui" line="318"/>
        <source>AL&amp;SA</source>
        <translation>AL&amp;SA</translation>
    </message>
</context>
<context>
    <name>qjackctlSocketList</name>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="326"/>
        <source>Output</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="336"/>
        <source>Input</source>
        <translation>Вход</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="349"/>
        <source>Socket</source>
        <translation>Сокет</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="507"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="460"/>
        <source>&lt;New&gt; - %1</source>
        <translation>&lt;Новый&gt; — %1</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="508"/>
        <source>%1 about to be removed:

&quot;%2&quot;

Are you sure?</source>
        <translation>%1 будет удалён:

«%2»

Вы уверены?</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="593"/>
        <source>%1 &lt;Copy&gt; - %2</source>
        <translation>%1 &lt;Копия&gt; — %2</translation>
    </message>
</context>
<context>
    <name>qjackctlSocketListView</name>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="754"/>
        <source>Output Sockets / Plugs</source>
        <translation>Выходные сокеты/штепсели</translation>
    </message>
    <message>
        <location filename="../qjackctlPatchbay.cpp" line="756"/>
        <source>Input Sockets / Plugs</source>
        <translation>Входные сокеты/штепсели</translation>
    </message>
</context>
</TS>
